=== EzUploads ===
Contributors: nuLL
Donate link: http://nullfix.com/ezuploads/
Tags: filehost, rapidshare, file, hosting
Stable tag: 1.7

EzUploads is an fast easy to use filehosting system script.

== Description ==

EzUpload UTILIZES Flash upload method to support faster upload and progress bars
without the use of external extensions in php or cgi libs. And also to
support big files without editing the php.ini (server side) limits!

Released as Donationware Software.

== Changelog ==
version 1.7 [ may 2012 ]
* script was designed to work on root of the host. with the help of one user that mailed me we fixed several paths that make the script installable on any subdirectory as well now. Thanks again Javier
* optimized code and script paths. (this makes the script easy installable now)
+ upload method that is compatible with all browsers flash based (hopefully)
* rework on all code has made. make sure to submit any bugs you find!
version 1.5 [ jan 2009 ]
* optimized login / registration / lost password forms and functions
* some optimization on file lists applied. (in admin and frontend gallery
+ new search function added in administration (for easy file find and delete/download action)
* optimizing code and script paths.
* fixed some errors in image uploading and file type recognition.
* more code smallfixes made and more will come�
version 1.4 [  ]
* optimized contact page.
+ new captcha system added.
version 1.3 [ 03 aug 2008 ]
+ public gallery page added.
+ new back end admin functions added!
+ image upload form and supporting pages added
+ multiple config's per user level added
+ improved profiles (members ability to manage files).
version 1.2 [ 10 july 2008 ]
* admin panel: user managment function added (edit/view/delete users)
* admin panel: purge files function added (delete files "last downloaded is" older than XX days)
* gravatar support in user public profiles.
* user profile page and editor added.
* fine tuning and testing usability.
+ registration system added. (login / registration) session managment and new db table.
* counter for download added for unregistered users.
* mod_rewrite support added for sorter download / page url's (.htaccess)
+ search page added (search real file names ability)
+ SQLite database implemented (warning: this is file based not mysql)
+ htaccess file added to protect "uploads" directory.
+ simple administration panel implemented.
* language xml file optimization (utf-8 support).
version 1.1 [ 03 july 2008 ]
+ multi language support. & session managment.
* new improved download functions implemented.
+ remote upload file size / type checks implemented.
* optimization & css for firefox/ie7+.
+ new theme implemented.

version 1.01 [ 28 june 2008 ]
+ added remote upload ability.
* some minor bugs fixes.

version 1.0 [ 25 june 2008 ]
! first release.

== Development Blog ==

[null's Development Blog]( http://nullfix.com/ )

== Installation ==

1. Edit config_site.php
2. config.php and config2.php are used for guest / member uploads check it out.
3. Chmod (database file) ezuploadx.dbz to 0666
4. Chmod uploadz & tmp directories to 0755 / 0666 / 0777 or what works better for your host.
5. Your site is ready (domain.com/admin) for administration login (password is in config_site.php).

Tested on dreamhost (shared hosting) it works 100%
For any problems and support use comments in my download page.

Enjoy my first Release! :)

Example / Demo:
http://ezuploads.net/

== Screenshots ==

[EzUploads Screenshots]( http://nullfix.com/ezuploads/ )

== Frequently Asked Questions ==

n/a
