<?php
/********************************************************

	Easy Uploads 1.5
	Release date: 25/08/2008
	Developers version: 1.5
	Copyright (C) nullfix.com

*********************************************************/
$_CONFIG['admin_pw']							  = 'xxxxxxx';                                                                                 // Administration password for CPanel
$_CONFIG['site_name']							  = 'Easy Uploads';                                                                            // Site Name
$_CONFIG['site_url']							  = 'http://ezuploads.net';																	   // Site URL
$_CONFIG['site_path']							  = '/home/hitec7/ezuploads.net/';                                                             // Site Directory Path
$_CONFIG['upload_dir']                            =  $_CONFIG['site_path'].'uploadz/';                                                         // Files Upload directory (used in admin)
$_CONFIG['from_email_address']                    = 'xxxxx@hotmail.com';                                                                      // mail to admin used in contact form page
$_CONFIG['allow_extensions']                      = '(divx|flv|wma|wmv|mp3|mpg|mpeg|avi|mov|swf|zip|rar|7z)';                                  // allow extensions for member remote upload!
$_CONFIG['max_upload_size']                       = 104857600;                                                                                 // Maximum upload size (5 * 1024 * 1024 = 5242880 = 5MB)
$_CONFIG['database_path']                         = 'ezuploadx.dbz';                                                                                        // Database Relative Path!

//////////////////////////////////////////////////
//  formatBytes($file_size) mixed file sizes
//  formatBytes($file_size, 0) KB file sizes
//  formatBytes($file_size, 1) MB file sizes etc
//////////////////////////////////////////////////
function formatBytes($bytes, $format=99){
	$byte_size = 1024;
	$byte_type = array(" KB", " MB", " GB", " TB", " PB", " EB", " ZB", " YB");

	$bytes /= $byte_size;
	$i = 0;

	if($format == 99 || $format > 7){
		while($bytes > $byte_size){
			$bytes /= $byte_size;
			$i++;
		}
	}
	else{
		while($i < $format){
			$bytes /= $byte_size;
			$i++;
		}
	}

	$bytes = sprintf("%1.2f", $bytes);
	$bytes .= $byte_type[$i];

	return $bytes;
}

// language class implementation
	class TalkPHP_MultiLingual
	{
		private $m_pXML;
		
		public function __construct($szPage, $szLanguage = 'US')
		{
			$this->m_pXML = simplexml_load_file(sprintf('./lang/%s/%s.xml', $szLanguage, $szPage));
		}
		
		public function getPhrase($szItem)
		{
			$aItem = $this->m_pXML->xpath(sprintf("//phrase[@id='%s']", $szItem));
			$szItem = empty($aItem[0]) ? null : (string) $aItem[0];	
			return $szItem;
		}
	}
	
	function p($szItem)
	{
		global $pLang;
		echo $pLang->getPhrase($szItem);
	}

	session_start();
	if(!session_id()) session_regenerate_id();
	if ($_REQUEST['p'] != 'action') { unset($_SESSION['captcha_code']); }

	if (isset($_REQUEST['lang'])) { $_SESSION['lang'] = $_REQUEST['lang'];	}

	if (!isset($_SESSION['lang'])) {
	$pLang = new TalkPHP_MultiLingual('index', 'US');
	} else {
	$pLang = new TalkPHP_MultiLingual('index', $_SESSION['lang']);
	}	
	/* Choose a way... */
	//echo $pLang->getPhrase('introduction');
	//p('introduction');
?>