<?php include('pages/header.php'); // include header.php ?>

<div id="accordian"><!--Parent of the Accordion-->

<?php
$default = 'home'; //Whatever default page you want to display if the file doesn't exist or you've just arrived to the home page.
$page = isset($_GET['p']) ? $_GET['p'] : $default; //Checks if ?p is set, and puts the page in and if not, it goes to the default page.
$page = basename($page); //Gets the page name only, and no directories.
if (!file_exists('pages/'.$page.'.php') || $_GET['p'] == 'header' || $_GET['p'] == 'footer' || $_GET['p'] == 'index')    { //Checks if the file doesn't exist
    $page = $default; //If it doesn't, it'll revert back to the default page
echo("<div align='center'><h4>Warning: Unknown page - Default Loaded!</h4></div>");
    //NOTE: Alternatively, you can make up a 404 page, and replace $default with whatever the page name is. Make sure it's still in the inc/ directory.
}
include('pages/'.$page.'.php'); //And now it's on your page!
?>

</div><!--End of accordion parent-->
<?php include('pages/footer.php'); // include footer.php ?>
