<div id="footer">
<div align="center">
<p><a href="./?p=tos" title="<?php p('heading3'); ?>"><?php p('heading3'); ?></a> | <a href="./?p=faq" title="<?php p('heading2'); ?>"><?php p('heading2'); ?></a> | <a href="./?p=contact" title="<?php p('heading4'); ?>"><?php p('heading4'); ?></a></p>
<script type="text/javascript"><!--
google_ad_client = "ca-pub-8330246531557951";
/* Bottom Banner EZUploads */
google_ad_slot = "4989730213";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
</div>
<p class="validate"><a href="http://validator.w3.org/check?uri=<?php echo $_CONFIG['site_url']; ?>">XHTML</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a><br /><a href="#header"><?php p('footer1'); ?></a></p>		

<!-- Please leave this line intact support donationware :) (script *ezUploads* developed by nuLL) -->
<p>script developed by <a href="http://nullfix.com" target="_blank" title="nuLL's Personal Blog">nuLL</a>. (<a href="http://nullfix.com/mycode/ezuploads/" target="_blank" title="How to support Development?">donationware</a>)<br />
<!-- you can delete below here -->
&copy; 2008 <?php echo $_CONFIG['site_name'] ;?>.</p>
</div>

<?php //echo $_CONFIG['config_file_name']; ?>
</body>
</html>