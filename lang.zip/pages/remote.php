<?php
//==== Redirect... Try PHP header redirect, then Java redirect, then try http redirect.:
function redirect($url){
    if (!headers_sent()){    //If headers not sent yet... then do php redirect
        header('Location: '.$url); exit;
    }else{                    //If headers are sent... do java redirect... if java disabled, do html redirect.
        echo '<script type="text/javascript">';
        echo 'window.location.href="'.$url.'";';
        echo '</script>';
        echo '<noscript>';
        echo '<meta http-equiv="refresh" content="0;url='.$url.'" />';
        echo '</noscript>'; exit;
    }
}//==== End -- Redirect


// CURL Remote Download
function curl_download($remote, $local)	{

if (function_exists('curl_init')) {
	$cp = curl_init($remote);
	$fp = fopen($local, "w");
	
	curl_setopt($cp, CURLOPT_FILE, $fp);
	curl_setopt($cp, CURLOPT_HEADER, 0);
	curl_setopt($cp, CURLOPT_CONNECTTIMEOUT, 15);
	curl_setopt($cp, CURLOPT_TIMEOUT, 900);
	
	curl_exec($cp);
	$curl_info = curl_getinfo($cp);
	mail('hitec7@hotmail.com', 'Curl Stats', print_r($curl_info, true));
	curl_close($cp);
	fclose($fp);
	} else {
    echo "CURL functions are not available on this Web server.<br />You cannot use remote uploads feature.<br />";
	}
}

// Random file name generator
function random_string($max_length = 20, $random_chars = "abcdefghijklmnopqrstuvwxyz0123456789")
{
			for ($i = 0; $i < $max_length; $i++) {
				$random_key = mt_rand(0, strlen($random_chars));
				$random_string .= substr($random_chars, $random_key, 1);
			}
			return strtolower(str_shuffle($random_string));
}

$javastart = '<script language="javascript" type="text/javascript">document.getElementById("loader").style.display="block";</script>';
$javastop = '<script language="javascript" type="text/javascript">document.getElementById("loader").style.display="none";</script>';
?>
<!--Start of each accordion item-->
  <div id="test3-header" class="accordion_headings header_highlight"><?php p('remote'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test3-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child" align="center">
	<?php include('pages/adstop.inc'); ?>
<script language="javascript" type="text/javascript">
<!-- Begin
function disableForm(theform) {
if (document.all || document.getElementById) {
for (i = 0; i < theform.length; i++) {
var tempobj = theform.elements[i];
if (tempobj.type.toLowerCase() == "submit" || tempobj.type.toLowerCase() == "reset")
tempobj.disabled = true;
}
//setTimeout('alert("Your form has been submitted.  Notice how the submit and reset buttons were disabled upon submission.")', 2000);
return true;
}
else {
//alert("The form has been submitted.  But, since you're not using IE 4+ or NS 6, the submit button was not disabled on form submission.");
return false;
   }
}
//  End -->
</script>
<div id="loader" style="display: none;"><i>remote upload in progress...</i><br /><img src="/pages/images/loader.gif" border="0" width="100px" height="100px" alt="fale Ajax loader" /></div>
<?php if ($_SESSION['user_logged'] === 1) { // only for logged in users ?>
<?php if (!isset($_POST['url'])) { ?>
<br />
<form method="post" action="" onsubmit="if(this.url.value==''){alert('Please enter a proper URL!\n\nExample: http://domain.com/file.zip');return false;}return disableForm(this);">
<div><a href="<?php echo $_CONFIG['site_url']; ?>"><?php p('normalupload'); ?></a></div>
<input id="big" type="text" name="url" size="30" />
<input id="big" type="submit" value="<?php p('remote'); ?>" onclick="document.getElementById('loader').style.display='block';" /></form>
<?php
}else{
$path_parts = pathinfo($_POST['url']);
$trimmed = trim($_CONFIG['allow_extensions'], ")(");
$noext = explode("|", $trimmed);

if ($path_parts['extension'] != '' && in_array($path_parts['extension'], $noext)) {

//session_start();
$dlid = random_string(6);
$delid = random_string(20);
$localfile = $_CONFIG['upload_dir'].$dlid;
set_time_limit(900);

curl_download($_POST['url'],$localfile);

// filesize check
$big = ( filesize($localfile) > $_CONFIG['max_upload_size'] ) ? "true" : "false";

$_SESSION['filesize'] = formatBytes(filesize($localfile));
$_SESSION['dlurl'] = $_CONFIG['site_url'].'/?p=action&dl='.$dlid;
$_SESSION['delurl'] = $_CONFIG['site_url'].'?p=action&dl='.$dlid.'&del='.$delid;
$_SESSION['filename'] = $path_parts['basename'];
$hostname = $_SERVER['REMOTE_ADDR'];

$redir = $_CONFIG['site_url']."/?p=finish";

// file size check
if ($big == 'true') {
$humanfilesize = formatBytes($_CONFIG['max_upload_size']);
@unlink($localfile); // delete file
echo $javastop;
echo '<h3>'.$pLang->getPhrase('error2').$humanfilesize.'</h3>'; 
} else {
// SQLite database write
$database = $_CONFIG['database_path'];
if ($db = sqlite_open($database, 0666, $sqliteerror)) { 
	sqlite_query($db, "INSERT INTO files (delete_id, real_name, file_name, size, download_time, upload_ip) VALUES ('".$delid."','".$_SESSION[filename]."','".$dlid."','".$_SESSION[filesize]."','".$_SERVER[REQUEST_TIME]."','".$hostname."')");

// update user uploads count
if ($_SESSION['user_logged'] === 1) {
$res3 = sqlite_array_query($db, "SELECT id,user_uploads FROM users WHERE id = '$_SESSION[user_id]'", SQLITE_ASSOC);
$dcount2 = $res3[0][user_uploads] + 1;
$dlluserupdate = sqlite_query($db, "UPDATE users SET user_uploads = '$dcount2' WHERE id = '$_SESSION[user_id]'");
$uploadupdate = sqlite_query($db, "UPDATE files SET user_id = '$_SESSION[user_id]' WHERE delete_id = '$delid'");
}

	sqlite_close($db);
} else {
    die($sqliteerror);
}
session_write_close();
redirect($redir);
}

}else {echo $javastop; echo '<h3>'.$pLang->getPhrase('error3').'</h3>';} // extension check
} // if url exists.
} // end if user is loggged in
else {echo $javastop; echo '<br /><br /><h3>'.$pLang->getPhrase('error7').'</h3>';}
?>
<br /><br />

    </div>   
  </div>
<!--End of each accordion item-->
