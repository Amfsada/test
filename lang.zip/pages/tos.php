<!--Start of each accordion item-->
  <div id="test2-header" class="accordion_headings" ><?php p('heading3'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test2-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child">
	
	<p><?php printf($pLang->getPhrase('tos1'), $_CONFIG['site_name'], $_CONFIG['site_name']); ?></p>
		<ul>
		<li><?php p('tos4'); ?></li>
		<li><?php p('tos5'); ?></li>
		<li><?php p('tos6'); ?></li>									
		<li><?php printf($pLang->getPhrase('tos7'), $_CONFIG['site_name']); ?></li>
		</ul>
	<p><?php printf($pLang->getPhrase('tos8'), $_CONFIG['site_name']); ?></p>
	<?php p('tos9'); ?> <a href="mailto:<?php echo $_CONFIG['from_email_address'] ;?>"><?php echo $_CONFIG['from_email_address'] ;?></a>

    </div>    
  </div>
<!--End of each accordion item--> 
