<!--Start of each accordion item-->
  <div id="test3-header" class="accordion_headings"><?php p('heading4'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test3-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child">	
		<p><?php p('contact1'); ?></p>
<?php		
//require_once('ascii_captcha.class.php');
if (isset($_POST['submitform']) && strtolower($_POST['code']) === strtolower($_SESSION['c_code']) && $_POST['email'] != 'Email Address') {

// headers for php mails
$headers = 'From: website@ezuploads.info' . "\r\n" .
    'Reply-To: '. $_POST['email'] . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

function imap8bit(&$item, $key) {
 $item = imap_8bit($item);
}

function email($e_mail, $subject, $message, $headers)
 {
  // add headers for utf-8 message
  $headers .= "\r\n";
  $headers .= "MIME-Version: 1.0\r\n";
  $headers .= "Content-type: text/plain; charset=utf-8\r\n";
  $headers .= "Content-Transfer-Encoding: quoted-printable\r\n";

  // encode subject
  //=?UTF-8?Q?encoded_text?=

  // work a round: for subject with wordwrap
  // not fixed, no possibility to have one in a single char
  $subject = wordwrap($subject, 25, "\n", FALSE);
  $subject = explode("\n", $subject);
  array_walk($subject, imap8bit);
  $subject = implode("\r\n ", $subject);
  $subject = "=?UTF-8?Q?".$subject."?=";

  // encode e-mail message
  $message = imap_8bit($message);

  return(mail("$e_mail", "$subject", "$message", "$headers"));
 }

$fullmsg = "Sender E-Mail:\r\n".$_POST['email']."\r\n Message:\r\n".$_POST['message'] ;
email($_CONFIG['from_email_address'], "Contact Form Submition", $fullmsg, $headers);
echo("<div align='center'><h3>".$pLang->getPhrase('formsubmit1').$_POST['name'].$pLang->getPhrase('formsubmit2')."</h3></div>");
unset($_SESSION['c_code']);
}
else {
?>
<script type="text/javascript">
var Handler = {
  clearedOnce : false,
  clear : function ( field ) {
    if (this.clearedOnce == false) {
      field.value = '';
      this.clearedOnce = false;
    }
  }
}
</script>

		<form method="post" action="" onsubmit="if(this.name.value=='Name' || this.email.value=='Email Address' || this.email.value=='' || this.message.value=='Message'){alert('Please complete all fields');return false;}return true;">
		<input id="big" onfocus="Handler.clear(this)" value="<?php p('contact2'); ?>" name="name" /><br /><br />
		<input id="big" onfocus="Handler.clear(this)" value="<?php p('contact3'); ?>" name="email" /><br /><br />
		<textarea id="big" cols="50" rows="5" name="message"><?php p('contact4'); ?></textarea><br /><br />
		<img src="getimage.php?<?php echo time(); ?>" alt="" name="captcha" width="155" height="45" id="captcha" /><br /><a href="javascript:void(0);" onclick="document.images['captcha'].src ='getimage.php'+ '?' + (new Date()).getTime();">Reload Captcha</a><br />
		<input id="big" onfocus="Handler.clear(this)" type="text" name="code" value="Captcha code" /><br /><br />
		<input id="big" name="submitform" type="submit" value="<?php p('contact5'); ?>" />
		</form>
<?php } ?>		
		<p><?php //print_r($_SESSION, false); ?></p>
    </div>
    
  </div>
<!--End of each accordion item-->