<?php //session_start(); ?>
<!--Start of each accordion item-->
<script type="text/javascript">
    function highlight(field) 
    {
      field.focus();
      field.select();
    }
</script>
  <div id="test3-header" class="accordion_headings header_highlight"><?php p('heading7'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test3-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child" align="center">
	<?php include('pages/adstop.inc'); ?>
<br />
<?php
// manage file uploads
if(isset($_SESSION[dlurl]) && $_SESSION['upload_type'] == 'files'){
echo '<b>'.$pLang->getPhrase('dlink').'</b><h3><a href="'.$_SESSION[dlurl].'">'.$_SESSION[dlurl].'</a></h3>';
echo '<small>'.$pLang->getPhrase('filename').$_SESSION[filename].$pLang->getPhrase('size').$_SESSION[filesize].'</small>';
echo '<br /><br />';
echo $pLang->getPhrase('deletelink').'<br /><small>'.$_SESSION[delurl].'</small>';
//session_unset();
//session_destroy();
unset($_SESSION['filesize']);
unset($_SESSION['dlurl']);
unset($_SESSION['delurl']);
unset($_SESSION['filename']);
}

// manage image uploads
if(isset($_SESSION['delurl']) && $_SESSION['upload_type'] == 'images'){
$thlink = '<a href="my.php?image='.$_SESSION['filename'].'" title="'.$pLang->getPhrase('imageuploads1').'"><img src="images/th_'.$_SESSION['filename'].'" border="0"/></a><br />'.$_SESSION['filename'];

echo '<table><tbody><tr><th>'.$pLang->getPhrase('imageuploads2').'</th><th>'.$pLang->getPhrase('imageuploads3').'</th></tr>';
echo '<tr>';
echo '<td>'.$thlink.'</td><td valign="top">
<div align="left">
'.$pLang->getPhrase('imageuploads4').':<br />
<input type="text" onclick=\'highlight(this);\' size="45" value="[IMG]'.$_CONFIG['site_url'].'/images/'.$_SESSION['filename'].'[/IMG]" /> Forums
<br />
<input type="text" onclick=\'highlight(this);\' size="45" value="&lt;img src=&quot;'.$_CONFIG['site_url'].'/images/'.$_SESSION['filename'].'&quot; alt=&quot;Image Hosted by ezUploads.info&quot;/&gt;" /> Sites
<br />
<br />      
<input type="text" onclick=\'highlight(this);\' size="45" value="'.$_CONFIG['site_url'].'/my.php?image='.$_SESSION['filename'].'" /> Friends
<br />
<br />'.$pLang->getPhrase('imageuploads5').':<br />
<input type="text" onclick=\'highlight(this);\' size="45" value="&lt;a href=&quot;'.$_CONFIG['site_url'].'/my.php?image='.$_SESSION['filename'].'&quot; target=&quot;_blank&quot;&gt;&lt;img src=&quot;'.$_CONFIG['site_url'].'/images/th_'.$_SESSION['filename'].'&quot; border=&quot;0&quot; /&gt;&lt/a&gt;" /> Sites
<br />
<input type="text" onclick=\'highlight(this);\' size="45" value="[URL='.$_CONFIG['site_url'].'/my.php?image='.$_SESSION['filename'].'][IMG]'.$_CONFIG['site_url'].'/images/th_'.$_SESSION['filename'].'[/IMG][/URL]" /> Forums
<br /><br />
<input type="text" onclick=\'highlight(this);\' size="45" value="'.$_CONFIG['site_url'].'/images/'.$_SESSION['filename'].'" /> Direct
<br /><br />
'.$pLang->getPhrase('imageuploads6').':<br />
<input type="text" onclick=\'highlight(this);\' size="45" value="'.$_SESSION['delurl'].'" />
</div>
</td>';
echo '</tr></tbody></table>';

unset($_SESSION['delurl']);
unset($_SESSION['filename']);
unset($_SESSION['filesize']);

}

// print error if there is no files to
//if(!isset($_SESSION['delurl']) && !isset($_SESSION[dlurl])) { echo "<h3>".$pLang->getPhrase('error1')."</h3>"; }

?>
<br /><br /><input id="big" type="button" value="<?php p('goback'); ?>" onClick="javascript:history.go(-1)">

    </div>
    
  </div>
<!--End of each accordion item-->