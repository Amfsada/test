<!--Start of each accordion item-->
  <div id="test3-header" class="accordion_headings header_highlight"><?php p('searchpage'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test3-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child" align="center">
<?php include('pages/adstop.inc'); ?>
<?php
// default search form
$results = '<br />'.
'<form method="post" action="">'.
'<input id="big" type="text" name="s" value="" size="30" />'.
'<input id="big" type="submit" value="'.$pLang->getPhrase(button3).'" /></form><p>'.$pLang->getPhrase(searchpage2).'</p>';

// search results fech!
if (isset($_POST['s']) && $_POST['s'] != '') {

$database = $_CONFIG['database_path'];
$srch="%".$_POST['s']."%"; 
$dbhandle = sqlite_open($database, 0666, $sqliteerror);
$query = sqlite_query($dbhandle, "SELECT real_name,file_name,size,downloads,user_id FROM files WHERE real_name LIKE '$srch' LIMIT 15");
$i = 0;

$results = '<h2>'.$pLang->getPhrase(searchpage3).'</h2><table><tbody><tr><th>No</th><th>'.$pLang->getPhrase(filename).'</th><th>DLL</th><th>'.$pLang->getPhrase(size).'</th><th>'.$pLang->getPhrase(actions).'</th></tr>';
while ($entry = sqlite_fetch_array($query, SQLITE_ASSOC))
  {
  $i++;
  $nametrim = (strlen($entry[real_name]) > 55) ? substr($entry[real_name], 0, 55) : $entry[real_name];
  $up_user = ($entry['user_id'] != 0) ? '<a title="Uploader\'s Profile" href="'.$_CONFIG['site_url'].'/?p=profile&amp;uid='.$entry[user_id].'"><img src="'.$_CONFIG['site_url'].'/pages/images/status_online.png" alt="user" /></a>&nbsp;' : '';
  $dlink = '<a title="'.$pLang->getPhrase(button1).'" href="'.$_CONFIG['site_url'].'/?p=action&dl='.$entry[file_name].'" target="_blank"><img src="'.$_CONFIG['site_url'].'/pages/images/dll.png" alt="download" /></a>';
  $results .= '<tr><td>'.$i.'</td><td>'.$nametrim.'</a></td><td>'.$entry[downloads].'</td>'.'<td>'.$entry[size].'</td><td>'.$up_user.$dlink.'</td></tr>';
  }
$results .= '</tbody></table>';
$results .= '<br /><br /><input id="big" type="button" value="'.$pLang->getPhrase(goback).'" onclick="javascript:location.href=\''.$_CONFIG['site_url'].'/?p=search\'">';

	if (sqlite_num_rows($query) == 0)
	{
	unset($results);
	$results = '<br /><br /><h3>'.$pLang->getPhrase(searcherror).'</h3>';
	$results .= '<br /><br /><input id="big" type="button" value="'.$pLang->getPhrase(goback).'" onclick="javascript:location.href=\''.$_CONFIG['site_url'].'/?p=search\'">';
	}
sqlite_close($dbhandle);
}

// Type results to the page!
echo $results;
?>
    </div>
    
  </div>
<!--End of each accordion item-->