<?php
session_start();
$char = strtoupper(substr(str_shuffle('abcdefghjkmnpqrstuvwxyz'), 0, 4));
$captcha_code = rand(1, 9) . rand(1, 9) . $char;
$_SESSION['c_code'] = $captcha_code;
header('Content-type: image/jpeg');
//header('Cache-control: no-cache');
$image = @imagecreate(155, 45) or die("Cannot Initialize new GD image stream");
$background_color = imagecolorallocate($image, 255, 255, 255);
$color = imagecolorallocate($image, rand(150, 50), rand(145, 120), rand(200, 155));
$font = 'verdana.ttf';
$rotate = rand(-8, 8);
imagettftext($image, 18, $rotate, 20, 35, $color, $font, $captcha_code);
for ($i=1; $i <=10; $i++){
imageline($image, 0, $i*rand(8, 10), 155, $i*rand(10, 8), $color);
imageline($image, $i*rand(16, 18), 0, $i*rand(14, 16), 45, $color);
}
imagerectangle($image,0,0,154,44,$color);
imagejpeg($image);
ImageDestroy($image);
?>