<?php include('pages/header.php'); // include header.php ?>

<div align="center">
<script type="text/javascript"><!--
google_ad_client = "pub-8330246531557951";
/* 468x60, created 6/29/08 */
google_ad_slot = "0611449782";
google_ad_width = 468;
google_ad_height = 60;
//-->
</script>
<script type="text/javascript"
src="http://pagead2.googlesyndication.com/pagead/show_ads.js">
</script>
<br />
<?php
if(isset($_GET['image']) && $_GET['image'] != '' && file_exists('images/'.$_GET['image'])) {

// SQLite get file info & update counter
$database = $_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$res = sqlite_array_query($db, "SELECT file_name,downloads,size FROM images WHERE file_name = '$_GET[image]'", SQLITE_ASSOC);
$dcount = $res[0][downloads] + 1;
$res2 = sqlite_query($db, "UPDATE images SET downloads = '$dcount', download_time = '$_SERVER[REQUEST_TIME]' WHERE file_name = '$_GET[image]'");

// update user download count
if ($_SESSION['user_logged'] === 1) {
$res3 = sqlite_array_query($db, "SELECT id,user_downloads FROM users WHERE id = '$_SESSION[user_id]'", SQLITE_ASSOC);
$dcount2 = $res3[0][user_downloads] + 1;
$dlluserupdate = sqlite_query($db, "UPDATE users SET user_downloads = '$dcount2' WHERE id = '$_SESSION[user_id]'");
}
sqlite_close($db);

$biglink = '<a href="'.$_CONFIG['site_url'].'/images/'.$res[0][file_name].'" title="Full Image Size!" target="_blank"><img src="images/'.$res[0][file_name].'" border="1" width="650" /></a><br /><h2>'.$res[0][file_name].' |'.$pLang->getPhrase('size').$res[0][size].' | '.$pLang->getPhrase('views').$res[0][downloads].'</h2>';
$smallink = '<img src="images/th_'.$res[0][file_name].'" border="1" /><br />'.$res[0][file_name].' | '.$pLang->getPhrase('views').$res[0][downloads];

echo $biglink;

$results = '<table><tbody><tr><th>'.$pLang->getPhrase('imageuploads3').'</th><th>'.$pLang->getPhrase('imageuploads2').'</th></tr>';
$results .= '<tr>';
$results .= '<td valign="top">
<div align="left">
'.$pLang->getPhrase('imageuploads4').':<br />
<input type="text" onclick=\'highlight(this);\' size="45" value="[IMG]'.$_CONFIG['site_url'].'/images/'.$res[0][file_name].'[/IMG]" /> Forums
<br />
<input type="text" onclick=\'highlight(this);\' size="45" value="&lt;img src=&quot;'.$_CONFIG['site_url'].'/images/'.$res[0][file_name].'&quot; alt=&quot;Image Hosted by ezUploads.info&quot;/&gt;" /> Sites
<br />
<br />      
<input type="text" onclick=\'highlight(this);\' size="45" value="'.$_CONFIG['site_url'].'/my.php?image='.$res[0][file_name].'" /> Friends
<br />
<br />'.$pLang->getPhrase('imageuploads5').':<br />
<input type="text" onclick=\'highlight(this);\' size="45" value="&lt;a href=&quot;'.$_CONFIG['site_url'].'/my.php?image='.$res[0][file_name].'&quot; target=&quot;_blank&quot;&gt;&lt;img src=&quot;http://'.$_CONFIG['site_url'].'/images/th_'.$res[0][file_name].'&quot; border=&quot;0&quot; /&gt;&lt/a&gt;" /> Sites
<br />
<input type="text" onclick=\'highlight(this);\' size="45" value="[URL='.$_CONFIG['site_url'].'/my.php?image='.$res[0][file_name].'][IMG]'.$_CONFIG['site_url'].'/images/th_'.$res[0][file_name].'[/IMG][/URL]" /> Forums
<br /><br />
<input type="text" onclick=\'highlight(this);\' size="45" value="'.$_CONFIG['site_url'].'/images/'.$res[0][file_name].'" /> Direct
</div>
</td><td>'.$smallink.'</td>';
$results .= '</tr></tbody></table>';
} else { $results = "<b>Sorry, that file does not exist!</b>"; }
?>
</div>
<div id="accordian"><!--Parent of the Accordion-->

<script type="text/javascript">
    function highlight(field) 
    {
      field.focus();
      field.select();
    }
</script>
<!--Start of each accordion item-->
  <div id="test3-header" class="accordion_headings header_highlight"><?php p('heading6'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test3-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child" align="center">
<?php include('pages/adstop.inc'); ?>
<?php echo $results; ?>
    </div>  
  </div>
<!--End of each accordion item-->
</div><!--End of accordion parent-->
<?php include('pages/footer.php'); // include footer.php ?>