<?php
header('Status: 404 Not Found');
header('HTTP/1.0 404 Not Found');
?>