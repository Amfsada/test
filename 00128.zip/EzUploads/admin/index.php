<?php
require_once('../config_site.php');
//unset($_SESSION['user_logged']);
//header('Status: 404 Not Found');
//header('HTTP/1.0 404 Not Found');

    if(!function_exists('how_long_ago')){
        function how_long_ago($timestamp){
            $difference = time() - $timestamp;

            if($difference >= 60*60*24*365){        // if more than a year ago
                $int = intval($difference / (60*60*24*365));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' year' . $s . ' ago';
            } elseif($difference >= 60*60*24*7*5){  // if more than five weeks ago
                $int = intval($difference / (60*60*24*30));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' month' . $s . ' ago';
            } elseif($difference >= 60*60*24*7){        // if more than a week ago
                $int = intval($difference / (60*60*24*7));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' week' . $s . ' ago';
            } elseif($difference >= 60*60*24){      // if more than a day ago
                $int = intval($difference / (60*60*24));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' day' . $s . ' ago';
            } elseif($difference >= 60*60){         // if more than an hour ago
                $int = intval($difference / (60*60));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' hour' . $s . ' ago';
            } elseif($difference >= 60){            // if more than a minute ago
                $int = intval($difference / (60));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' minute' . $s . ' ago';
            } else {                                // if less than a minute ago
                $r = 'moments ago';
            }

            return $r;
        }
    }

// login & form
if ($_SESSION['user_logged'] != 'true' || !isset($_SESSION['user_logged'])) {
//unset($_SESSION['user_logged']);
$sreply = 'You are not logged in please fill the password below.';
$_SESSION['user_logged'] = ($_POST['pass'] == $_CONFIG['admin_pw']) ? 'true' : 'false';

if (isset($_POST['pass']))	{
$sreply = ($_POST['pass'] == $_CONFIG['admin_pw']) ? 'Password Accepted you are now logged in. Click <a href="" target="Click to see CPanel">here</a> to access CPanel.' : 'Invalid Password!';
		}

$results = '<h3>'.$sreply.'</h3>'.
'<br /><br />'.
'<form method="post" action="">'.
'<input id="big" type="password" name="pass" value="" /><br />'.
'<input id="big" type="submit" value="Login" /></form><br /><br />';
}

// main admin page
if ($_SESSION['user_logged'] == 'true')
{
$results = '<div style="float:right; font-size:10px;"><b><a href="?action=viewfiles" title="View/Edit/Delete Files">File Managment</a> :: <a href="?action=viewimages" title="View/Edit/Delete Images">Image Managment</a> :: <a href="?action=purge" title="Massive delete files older than XX days!">Purge files</a> :: <a href="?action=check" title="Massive delete unused files!">File integrity check</a> :: <a href="?action=viewusers" title="View/Edit/Delete Users">User Managment</a> :: <a href="?action=logout" title="Logout from CP">Logout</a></b></div>'.
'<br /><br />';

if ($_REQUEST['action'] == 'logout') { unset($_SESSION['user_logged']); }

}

// file / image checker & delete routine
if ($_REQUEST['action'] == 'check' && $_SESSION['user_logged'] == 'true') {

// display the form
$sreply = "Check if the files physically exists against our database.";
$results = '<h3>'.$sreply.'</h3>'.
'<br /><br />'.
'<form method="post" action="">'.
'<input type="radio" name="type" value="files" checked /> Files <input type="radio" name="type" value="images" /> Images<br />'.
'choose witch section of database to check<br />'.
'<input type="submit" value="Check" onclick="return confirm(\'This function will delete unused files from your upload directory are you sure you want to do this?\')" /></form>';

if (isset($_POST['type'])) {
// SQLite Read DB Array
$database = '../'.$_CONFIG['database_path'];
$dbhandle = sqlite_open($database);
$query = ($_POST['type'] == 'files') ? sqlite_query($dbhandle, "SELECT id,file_name FROM files") : sqlite_query($dbhandle, "SELECT id,file_name FROM images");

/**
* directory_list
* return an array containing optionally all files, only directiories or only files at a file system path
* @author     cgray The Metamedia Corporation www.metamedia.us
*
* @param    $base_path         string    either absolute or relative path
* @param    $filter_dir        boolean    Filter directories from result (ignored except in last directory if $recursive is true)
* @param    $filter_files    boolean    Filter files from result
* @param    $exclude        string    Pipe delimited string of files to always ignore
* @param    $recursive        boolean    Descend directory to the bottom?
* @return    $result_list    array    Nested array or false
* @access public
* @license    GPL v3
*/
function directory_list($directory_base_path, $filter_dir = false, $filter_files = false, $exclude = ".|..|.DS_Store|.svn", $recursive = true){
    $directory_base_path = rtrim($directory_base_path, "/") . "/";

    if (!is_dir($directory_base_path)){
        error_log(__FUNCTION__ . "File at: $directory_base_path is not a directory.");
        return false;
    }

    $result_list = array();
    $exclude_array = explode("|", $exclude);

    if (!$folder_handle = opendir($directory_base_path)) {
        error_log(__FUNCTION__ . "Could not open directory at: $directory_base_path");
        return false;
    }else{
        while(false !== ($filename = readdir($folder_handle))) {
            if(!in_array($filename, $exclude_array)) {
                if(is_dir($directory_base_path . $filename . "/")) {
                    if($recursive && strcmp($filename, ".")!=0 && strcmp($filename, "..")!=0 ){ // prevent infinite recursion
                        error_log($directory_base_path . $filename . "/");
                        $result_list[$filename] = directory_list("$directory_base_path$filename/", $filter_dir, $filter_files, $exclude, $recursive);
                    }elseif(!$filter_dir){
                        $result_list[] = $filename;
                    }
                }elseif(!$filter_files){
                    $result_list[] = $filename;
                }
            }
        }
        closedir($folder_handle);
        return $result_list;
    }
}

$results = "<font color=red>DB Check begins ...</font><br /><br />";
while ($entry = sqlite_fetch_array($query, SQLITE_ASSOC))
{

$dbfiles[] .= $entry['file_name'];

if($_POST['type'] == 'files') {

$filename = $_CONFIG['upload_dir'].$entry['file_name'];
$handle = file_exists($filename);
$dirfiles = directory_list($_CONFIG['upload_dir']);

if($handle != true) { $results .= $entry['file_name'].'<font color=red> is Missing!</font><br />'; $queryz = sqlite_query($dbhandle, "DELETE FROM files WHERE file_name = '$entry[file_name]'"); }
} else {

$filename = $_SERVER['DOCUMENT_ROOT'].'/images/'.$entry['file_name'];
$handle = file_exists($filename);
$dirfiles = directory_list($_SERVER['DOCUMENT_ROOT'].'/images/');

if($handle != true) { $results .= $entry['file_name'].'<font color=red> is Missing!</font><br />'; $queryz = sqlite_query($dbhandle, "DELETE FROM images WHERE file_name = '$entry[file_name]'"); }
} // end post if else
} // end while
$results .= "<br /><font color=green>DB Check Completed...</font><br /><br />";
$results .= "<font color=red>Check & Delete unused files in our web server ...</font><br /><br />";

foreach ($dirfiles as $dir) {

if (!in_array($dir, $dbfiles) && $dir != 'index.php' && $dir != '.htaccess' && $dir != 'index.htm' && substr_compare($dir, "th_", 0, 3) != 0) {
$results .= "file: $dir is missing from our db! DELETING!<br />";
if ($_POST['type'] == 'files') {$filename1 = $_CONFIG['upload_dir'].$dir; @unlink($filename1);}else{$filename2 = $_SERVER['DOCUMENT_ROOT'].'/images/'.$dir; $filename3 = $_SERVER['DOCUMENT_ROOT'].'/images/th_'.$dir; @unlink($filename2); @unlink($filename3);}
}

}

$results .= '<br /><font color=green>Check & Delete ends...</font><br />';

sqlite_close($dbhandle);
} // end isset post type

} // action check!

// file purge routine
if ($_REQUEST['action'] == 'purge' && $_SESSION['user_logged'] == 'true') {

// display the form
$sreply = "Delete files that \"last time downloaded\" is older than <font color='red'>XX</font> days.<br />(<font color='red'>WARNING: actions here is unrecoverable!</font>)";
$results = '<h3>'.$sreply.'</h3>'.
'<br /><br />'.
'<form method="post" action="">'.
'<input type="radio" name="type" value="anonymous" checked /> Anonymous uploads <input type="radio" name="type" value="register" /> Registered user uploads<br />'.
'<input type="text" name="days" value="" size="5" /><br />How many days to purge? example: 30<br />'.
'<input type="submit" value="Submit" onclick="return confirm(\'Are you sure you want to delete those files?\')" /></form>';

if ($_POST['days'] != '' && isset($_POST['type'])) {
// SQLite Read DB Array
$database = '../'.$_CONFIG['database_path'];
$dbhandle = sqlite_open($database);
$query = ($_POST['type'] == 'anonymous') ? sqlite_query($dbhandle, "SELECT id,file_name,download_time FROM files WHERE user_id = 0") : sqlite_query($dbhandle, "SELECT id,delete_id,file_name,download_time FROM files WHERE user_id > 0");

$results = "<font color=red>Begin deletion of files older than ".$_POST['days']." days ...</font><br /><br />";
while ($entry = sqlite_fetch_array($query, SQLITE_ASSOC))
{
  $difference = time() - $entry['download_time'];
  $daysold = intval($difference / (60*60*24));

  if (intval($_POST['days']) <= $daysold) {
	$results .= "file <font color=red>".$entry['file_name']."</font> that is <font color=red>".$daysold."</font> days old deleted!<br />";
	$deletefromdb = sqlite_query($dbhandle, "DELETE FROM files WHERE id = '$entry[id]'"); // delete file from database
	$filename = $_CONFIG['upload_dir'].$entry['file_name'];
	@unlink($filename); // delete the actual file in uploads directory
	}

}
$results .= "<br /><font color=green>Action Completed.</font>";
sqlite_close($dbhandle);
	}

}

// delete file routine
if ($_REQUEST['action'] == 'delete' && $_REQUEST['fileidz'] != '' && $_SESSION['user_logged'] == 'true')	{

// get contents of a file into a string
$filename = $_CONFIG['upload_dir'].$_REQUEST['fileidz'];
$handle = file_exists($filename);

//if ($handle != true) {$results = "<h3>This file does not exist!</h3>";} else {
// SQLite Delete Database file
$database = '../'.$_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$query = sqlite_query($db, "DELETE FROM files WHERE file_name = '$_REQUEST[fileidz]'");
sqlite_close($db);
@unlink($filename); // delete the actual file
$results = "<h3>File: ".$_REQUEST['fileidz']." successfully Deleted!</h3>";
//}

}

// delete image routine
if ($_REQUEST['action'] == 'delete' && $_REQUEST['imageid'] != '' && $_SESSION['user_logged'] == 'true')	{

// get contents of a file into a string
$filename = $_CONFIG['site_path'].'/images/'.$_REQUEST['imageid'];
$thumb = $_CONFIG['site_path'].'/images/th_'.$_REQUEST['imageid'];
$handle = file_exists($filename);

//if ($handle != true) {$results = "<h3>This file does not exist!</h3>";} else {
// SQLite Delete Database file
$database = '../'.$_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$query = sqlite_query($db, "DELETE FROM images WHERE file_name = '$_REQUEST[imageid]'");
sqlite_close($db);
@unlink($filename); // delete the actual file
@unlink($thumb);
$results = "<h3>File: ".$_REQUEST['imageid']." successfully Deleted!</h3>";
//}

}

// delete user routine
if ($_REQUEST['action'] == 'delete' && $_REQUEST['userid'] != '' && $_SESSION['user_logged'] == 'true')	{

// SQLite Delete Database user
$database = '../'.$_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$query = sqlite_query($db, "DELETE FROM users WHERE id = '$_REQUEST[userid]'");

if (sqlite_changes($db) == 0) {
// if user does not exist!
$results = "<h3>This user does not exist!</h3>";
} else {
// all went ok! :)
$results = "<h3>Userid: ".$_REQUEST['userid']." successfully Deleted!</h3>";
	}
sqlite_close($db);

}

// edit file routine
if ($_REQUEST['action'] == 'edit' && $_REQUEST['fileidz'] != '' && $_SESSION['user_logged'] == 'true')	{
// SQLite get file data to place to the form
$database = '../'.$_CONFIG['database_path'];
$dbhandle = sqlite_open($database);
$query = sqlite_query($dbhandle, "SELECT id,real_name,file_name,size,download_time,upload_ip,downloads FROM files WHERE file_name = '$_REQUEST[fileidz]'");

while ($formentry = sqlite_fetch_array($query, SQLITE_ASSOC)){
$results = '<div align="left"><p>Warning: Do NOT change fields that can harm the script functionality.</p>';
$results .= '<form action="" method="post">';
$results .= '<input name="edit1" size="20" value="'.$formentry[real_name].'" /> File Real Name<br />';
$results .= '<input name="edit2" value="'.$formentry[upload_ip].'" /> Uploaders Ip<br />';
$results .= '<input name="edit3" value="'.$formentry[downloads].'" /> Download Counter<br />';
$results .= '<input name="edit4" value="'.$formentry[size].'" /> File Size<br />';
$results .= '<input type="hidden" name="edit5" value="'.$formentry[id].'" />';
$results .= '<input type="submit" value="Edit" />';
$results .= '</form>';
$results .= '<p>Last time downloaded: '.how_long_ago($formentry[download_time]).'</p></div>';
	}
sqlite_close($dbhandle);

}

if ($_POST['edit1'] != '' && $_POST['edit2'] != '' && $_POST['edit3'] != '' && $_POST['edit4'] != '' && $_POST['edit5'] != '' && $_SESSION['user_logged'] == 'true') {
// SQLite write changes to the database
$database = '../'.$_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$res2 = sqlite_query($db, "UPDATE files SET real_name = '$_POST[edit1]', upload_ip = '$_POST[edit2]', downloads = '$_POST[edit3]', size = '$_POST[edit4]' WHERE id = '$_POST[edit5]'");
sqlite_close($db);

unset($results);
$results = '<p>File: '.$_POST[edit1].' has been successfully edited!</p>';
}

// edit user routine
if ($_REQUEST['action'] == 'edit' && $_REQUEST['userid'] != '' && $_SESSION['user_logged'] == 'true')	{
// SQLite get file data to place to the form
$database = '../'.$_CONFIG['database_path'];
$dbhandle = sqlite_open($database);
$query = sqlite_query($dbhandle, "SELECT id,user_nick,user_mail,user_web,user_uploads,user_downloads,user_laston FROM users WHERE id = '$_REQUEST[userid]'");

while ($formentry = sqlite_fetch_array($query, SQLITE_ASSOC)){
$results = '<div align="left"><p>Warning: Do NOT change fields that can harm the script functionality.</p>';
$results .= '<form action="" method="post">';
$results .= '<input name="uedit1" size="15" value="'.$formentry[user_nick].'" /> nickname<br />';
$results .= '<input name="uedit2" size="30" value="'.$formentry[user_mail].'" /> e-mail<br />';
$results .= '<input name="uedit3" size="30" value="'.$formentry[user_web].'" /> website<br />';
$results .= '<input name="uedit4" size="6" value="'.$formentry[user_uploads].'" /> uploads<br />';
$results .= '<input name="uedit5" size="6" value="'.$formentry[user_downloads].'" /> downloads<br />';
$results .= '<input type="hidden" name="uedit6" value="'.$formentry[id].'" />';
$results .= '<input type="submit" value="Edit" />';
$results .= '</form>';
$results .= '<p>Last time online: '.how_long_ago($formentry[user_laston]).'</p></div>';
	}
sqlite_close($dbhandle);

}

if ($_POST['uedit1'] != '' && $_POST['uedit2'] != '' && $_POST['uedit4'] != '' && $_POST['uedit5'] != '' && $_POST['uedit6'] != '' && $_SESSION['user_logged'] == 'true') {
// SQLite write changes to the database
$database = '../'.$_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$res2 = sqlite_query($db, "UPDATE users SET user_nick = '$_POST[uedit1]', user_mail = '$_POST[uedit2]', user_web = '$_POST[uedit3]', user_uploads = '$_POST[uedit4]', user_downloads = '$_POST[uedit5]' WHERE id = '$_POST[uedit6]'");
sqlite_close($db);

unset($results);
$results = '<p>User: '.$_POST[uedit1].' has been successfully edited!</p>';
}

// search results fech!
if (isset($_POST['s']) && $_POST['s'] != '' && $_SESSION['user_logged'] == 'true') {

$database = '../'.$_CONFIG['database_path'];
$srch="%".$_POST['s']."%"; 
$dbhandle = sqlite_open($database, 0666, $sqliteerror);
$query = sqlite_query($dbhandle, "SELECT real_name,file_name,size,downloads,user_id FROM files WHERE real_name LIKE '$srch' LIMIT 5");
$i = 0;

$results = '<h2>Search Results</h2><table><tbody><tr><th>No</th><th>File Name</th><th>DLL</th><th>Size</th><th>Actions</th></tr>';
while ($entry = sqlite_fetch_array($query, SQLITE_ASSOC))
  {
  $i++;
  $nametrim = (strlen($entry[real_name]) > 55) ? substr($entry[real_name], 0, 55) : $entry[real_name];
  $deletefile = '<a href="?action=delete&fileidz='.$entry[file_name].'" title="Delete this file" onclick="return confirm(\'Are you sure you want to delete this file?\')"><img src="../pages/images/exclamation.png" alt="delete" /></a>';
  $dlink = '<a title="'.$pLang->getPhrase(button1).'" href="'.$_CONFIG['site_url'].'/?p=action&dl='.$entry[file_name].'" target="_blank"><img src="'.$_CONFIG['site_url'].'/pages/images/dll.png" alt="download" /></a>';
  $results .= '<tr><td>'.$i.'</td><td>'.$nametrim.'</a></td><td>'.$entry[downloads].'</td>'.'<td>'.$entry[size].'</td><td>'.$deletefile.$dlink.'</td></tr>';
  }
$results .= '</tbody></table>';
$results .= '<br /><br />';

	if (sqlite_num_rows($query) == 0)
	{
	unset($results);
	$results = '<br /><br /><h3>No Results for your Query</h3>';
	$results .= '<br /><br />';
	}
sqlite_close($dbhandle);
}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="<?php echo $_CONFIG['site_name'] ;?> - Free File Hosting, Free Image Hosting, Free Music Hosting, Free Video Hosting" />
<meta name="keywords" content="<?php echo $_CONFIG['site_name'] ;?>,uploadservice,250 mb,mb,ftp hosting service,large file upload,secure file upload,file upload,web file upload,webspace,gratis webspace,kostenloser webspace,free webspace,webspace webhosting,hosting,hosting service,webhosting,upload files,mp3 upload,unlimited hosting" />
<title><?php echo $_CONFIG['site_name'] ;?> - <?php p('pagetitle'); ?></title>
<link rel="stylesheet" href="../pages/style.css" type="text/css" media="screen" />
<link rel="shortcut icon" href="<?php echo $_CONFIG['site_url'] ;?>/favicon.ico" />
</head>
<body>
<div id="header">
<?php //print_r($_POST, false); ?>
<h1><a href="index.php">ezUploads</a></h1>
<h2><?php printf($pLang->getPhrase('introduction1'), $_CONFIG['site_name']); ?></h2>
</div>

<div id="accordian" ><!--Parent of the Accordion-->
<!--Start of each accordion item-->
  <div id="test-header" class="admin_headings" >Control Panel</div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child" align="center">

<?php echo $results; ?>

<?php
// user viewer
if ($_REQUEST['action'] == 'viewusers' && $_SESSION['user_logged'] == 'true') 
		{
echo '<h2>Users Database</h2><table><tbody><tr><th>Id</th><th>Username</th><th>DLL</th><th>UP</th><th>User\'s IP</th><th>Actions</th></tr>';

// how many rows to show per page
$rowsPerPage = 20;

// by default we show first page
$pageNum = 1;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
    $pageNum = $_GET['page'];
}
// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;

// SQLite Read DB Array
$database = '../'.$_CONFIG['database_path'];
$dbhandle = sqlite_open($database);
$query = sqlite_query($dbhandle, "SELECT id,user_nick,user_downloads,user_uploads,user_ip,user_laston FROM users ORDER BY id DESC LIMIT $offset, $rowsPerPage");
$query2 = sqlite_query($dbhandle, "SELECT id FROM users");
$numrows = sqlite_num_rows($query2);

while ($entry = sqlite_fetch_array($query, SQLITE_ASSOC))
{

  //$nametrim = (strlen($entry[real_name]) > 45) ? substr($entry[real_name], 0, 45) : $entry[real_name];
  $time = '<a href="#" title="last time online: '.how_long_ago($entry[user_laston]).'"><img src="../pages/images/clock.png" alt="time" /></a>';
  $deleteuser = '<a href="?action=delete&userid='.$entry[id].'" title="Delete this user" onclick="return confirm(\'Are you sure you want to delete this user?\')"><img src="../pages/images/exclamation.png" alt="delete" /></a>';
  $edituser = '<a href="?action=edit&userid='.$entry[id].'" title="edit this user"><img src="../pages/images/eye.png" alt="edit" /></a>';
  echo "<tr><td>".$entry[id]."</td><td>".$entry[user_nick]."</a></td><td>".$entry[user_downloads]."</td>".
  "<td>".$entry[user_uploads]."</td><td>".$entry[user_ip]."</td><td>".$edituser.$time.$deleteuser."</td></tr>";

}
echo '</tbody></table>';

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

// print the link to access each page
$self = $_SERVER['PHP_SELF'];

// creating previous and next link
// plus the link to go straight to
// the first and last page

if ($pageNum > 1)
{
   $page  = $pageNum - 1;
   $prev  = " <a href=\"$self?action=viewusers&page=$page\">[Prev]</a> ";

   $first = " <a href=\"$self?action=viewusers&page=1\">[First Page]</a> ";
}
else
{
   $prev  = '&nbsp;'; // we're on page one, don't print previous link
   $first = '&nbsp;'; // nor the first page link
}

if ($pageNum < $maxPage)
{
   $page = $pageNum + 1;
   $next = " <a href=\"$self?action=viewusers&page=$page\">[Next]</a> ";

   $last = " <a href=\"$self?action=viewusers&page=$maxPage\">[Last Page]</a> ";
}
else
{
   $next = '&nbsp;'; // we're on the last page, don't print next link
   $last = '&nbsp;'; // nor the last page link
}

// print the navigation link
echo $first . $prev . " Showing page $pageNum of $maxPage pages " . $next . $last;

// and close the database connection
sqlite_close($dbhandle);
		} 

// files viewer
if ($_REQUEST['action'] == 'viewfiles' && $_SESSION['user_logged'] == 'true') 
		{
echo '<h2>Files Database</h2><table><tbody><tr><th>No</th><th>Filename</th><th>DLL</th><th>Size</th><th>Uploader\'s IP</th><th>Actions</th></tr>';

echo ''.
'<form method="post" action="">'.
'<input type="text" name="s" value="" size="30" />'.
'<input type="submit" value="Search Files" /></form><p>'.$pLang->getPhrase(searchpage2).'</p>';

// how many rows to show per page
$rowsPerPage = 20;

// by default we show first page
$pageNum = 1;
//$i = 0;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
    $pageNum = $_GET['page'];
}
// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;

// SQLite Read DB Array
$database = '../'.$_CONFIG['database_path'];
$dbhandle = sqlite_open($database);
$query = sqlite_query($dbhandle, "SELECT id,real_name,file_name,size,download_time,upload_ip,downloads FROM files ORDER BY id DESC LIMIT $offset, $rowsPerPage");
$query2 = sqlite_query($dbhandle, "SELECT id FROM files");
$numrows = sqlite_num_rows($query2);

while ($entry = sqlite_fetch_array($query, SQLITE_ASSOC))
{

  $i++;
  $nametrim = (strlen($entry[real_name]) > 45) ? substr($entry[real_name], 0, 45) : $entry[real_name];
  $time = '<a href="#" title="last time downloaded: '.how_long_ago($entry[download_time]).'"><img src="../pages/images/clock.png" alt="downloaded" /></a>';
  $deletefile = '<a href="?action=delete&fileidz='.$entry[file_name].'" title="Delete this file" onclick="return confirm(\'Are you sure you want to delete this file?\')"><img src="../pages/images/exclamation.png" alt="delete" /></a>';
  $editfile = '<a href="?action=edit&fileidz='.$entry[file_name].'" title="edit this file"><img src="../pages/images/eye.png" alt="edit" /></a>';
  echo "<tr><td>".$entry[id]."</td><td><a href=\"../?p=action&dl=".$entry[file_name]."\" target=\"_blank\">".$nametrim."</a></td><td>".$entry[downloads]."</td>".
  "<td>".$entry[size]."</td><td>".$entry[upload_ip]."</td><td>".$editfile.$time.$deletefile."</td></tr>";

}
echo '</tbody></table>';

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

// print the link to access each page
$self = $_SERVER['PHP_SELF'];

// creating previous and next link
// plus the link to go straight to
// the first and last page

if ($pageNum > 1)
{
   $page  = $pageNum - 1;
   $prev  = " <a href=\"$self?action=viewfiles&page=$page\">[Prev]</a> ";

   $first = " <a href=\"$self?action=viewfiles&page=1\">[First Page]</a> ";
}
else
{
   $prev  = '&nbsp;'; // we're on page one, don't print previous link
   $first = '&nbsp;'; // nor the first page link
}

if ($pageNum < $maxPage)
{
   $page = $pageNum + 1;
   $next = " <a href=\"$self?action=viewfiles&page=$page\">[Next]</a> ";

   $last = " <a href=\"$self?action=viewfiles&page=$maxPage\">[Last Page]</a> ";
}
else
{
   $next = '&nbsp;'; // we're on the last page, don't print next link
   $last = '&nbsp;'; // nor the last page link
}

// print the navigation link
echo $first . $prev . " Showing page $pageNum of $maxPage pages " . $next . $last;

// and close the database connection
sqlite_close($dbhandle);
		}

// image viewer
if ($_REQUEST['action'] == 'viewimages' && $_SESSION['user_logged'] == 'true') 
		{
echo '<h2>Images Database</h2><table><tbody><tr><th>No</th><th>Filename</th><th>Views</th><th>Size</th><th>Uploader\'s IP</th><th>Actions</th></tr>';

// how many rows to show per page
$rowsPerPage = 20;

// by default we show first page
$pageNum = 1;
//$i = 0;

// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
    $pageNum = $_GET['page'];
}
// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;

// SQLite Read DB Array
$database = '../'.$_CONFIG['database_path'];
$dbhandle = sqlite_open($database);
$query = sqlite_query($dbhandle, "SELECT id,file_name,size,download_time,upload_ip,downloads FROM images ORDER BY id DESC LIMIT $offset, $rowsPerPage");
$query2 = sqlite_query($dbhandle, "SELECT id FROM images");
$numrows = sqlite_num_rows($query2);

while ($entry = sqlite_fetch_array($query, SQLITE_ASSOC))
{

  $i++;
  $time = '<a href="#" title="last time viewed: '.how_long_ago($entry[download_time]).'"><img src="../pages/images/clock.png" alt="downloaded" /></a>';
  $deletefile = '<a href="?action=delete&imageid='.$entry[file_name].'" title="Delete this file" onclick="return confirm(\'Are you sure you want to delete this image?\')"><img src="../pages/images/exclamation.png" alt="delete" /></a>';
  $editfile = '<a href="?action=edit&imageid='.$entry[file_name].'" title="edit this file"><img src="../pages/images/eye.png" alt="edit" /></a>';
  echo "<tr><td>".$entry[id]."</td><td><a href=\"../my.php?image=".$entry[file_name]."\" target=\"_blank\">".$entry[file_name]."</a></td><td>".$entry[downloads]."</td>".
  "<td>".$entry[size]."</td><td>".$entry[upload_ip]."</td><td>".$editfile.$time.$deletefile."</td></tr>";

}
echo '</tbody></table>';

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

// print the link to access each page
$self = $_SERVER['PHP_SELF'];

// creating previous and next link
// plus the link to go straight to
// the first and last page

if ($pageNum > 1)
{
   $page  = $pageNum - 1;
   $prev  = " <a href=\"$self?action=viewimages&page=$page\">[Prev]</a> ";

   $first = " <a href=\"$self?action=viewimages&page=1\">[First Page]</a> ";
}
else
{
   $prev  = '&nbsp;'; // we're on page one, don't print previous link
   $first = '&nbsp;'; // nor the first page link
}

if ($pageNum < $maxPage)
{
   $page = $pageNum + 1;
   $next = " <a href=\"$self?action=viewimages&page=$page\">[Next]</a> ";

   $last = " <a href=\"$self?action=viewimages&page=$maxPage\">[Last Page]</a> ";
}
else
{
   $next = '&nbsp;'; // we're on the last page, don't print next link
   $last = '&nbsp;'; // nor the last page link
}

// print the navigation link
echo $first . $prev . " Showing page $pageNum of $maxPage pages " . $next . $last;

// and close the database connection
sqlite_close($dbhandle);
		}
?>

	</div>
  </div>
<!--End of each accordion item-->
</div><!--End of accordion parent-->

<div id="footer"><!--Start of footer-->

<p class="validate"><a href="http://validator.w3.org/check?uri=<?php echo $_CONFIG['site_url']; ?>/admin/">XHTML</a> | <a href="http://jigsaw.w3.org/css-validator/check/referer">CSS</a><br /><a href="#header">Top</a></p>
<!-- Please leave this line intact support donationware :) (script *ezUploads* developed by nuLL) -->
<p><br />script developed by <a href="http://nullfix.com" target="_blank" title="nuLL's Personal Blog">nuLL</a>. (<a href="http://nullfix.com/mycode/ezuploads/" target="_blank" title="How to support Development?">donatioware</a>)<br />
<!-- you can delete below here -->
&copy; 2008 <?php echo $_CONFIG['site_name'] ;?>.</p>

</div><!--End of footer-->
</body>
</html>
