<?php
$THIS_VERSION = '1.7';

// gamw to spiti sou!!!
require 'config_site.php';

if($PHP_ERROR_REPORTING){ error_reporting(E_ALL); }

header('Content-type: text/html; charset=UTF-8');
header('Expires: Mon, 26 Jul 1997 05:00:00 GMT');
header('Last-Modified: ' . date('r'));
header('Cache-Control: no-store, no-cache, must-revalidate');
header('Cache-Control: post-check=0, pre-check=0', FALSE);
header('Pragma: no-cache');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="description" content="<?php echo $_CONFIG['site_name'] ;?> - Free File Hosting, Free Image Hosting, Free Music Hosting, Free Video Hosting" />
<meta name="keywords" content="<?php echo $_CONFIG['site_name'] ;?>,uploadservice,250 mb,mb,ftp hosting service,large file upload,secure file upload,file upload,web file upload,webspace,gratis webspace,kostenloser webspace,free webspace,webspace webhosting,hosting,hosting service,webhosting,upload files,mp3 upload,unlimited hosting" />
<meta name="generator" content="ezUploads 1.5" />
<title><?php echo $_CONFIG['site_name'] ;?> - <?php p('pagetitle'); ?></title>
<link rel="stylesheet" href="<?php echo $_CONFIG['site_url'] ;?>/pages/style.css" type="text/css" media="screen" />
<script src="<?php echo $_CONFIG['site_url'] ;?>/pages/global.js" type="text/javascript"></script>
<link rel="shortcut icon" href="<?php echo $_CONFIG['site_url'] ;?>/favicon.ico" />

<?php if (!isset($_GET['p']) || $_GET['p'] == 'images') { ?>

<?php } ?>

<script type="text/javascript" src="js/SolmetraUploader.js"></script>
<script type="text/javascript">
SolmetraUploader.setErrorHandler('test');
function test (id, str) { alert('ERROR: ' + str); }
</script>

<script type="text/javascript">

  var _gaq = _gaq || [];
  _gaq.push(['_setAccount', 'UA-4771730-6']);
  _gaq.push(['_trackPageview']);

  (function() {
    var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
    ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
    var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
  })();

</script>

</head>
<body>
<div id="header">
<?php
// user icon setup
if ($_SESSION['user_logged'] === 1) {
// SQLite load login info to check if its true ;)
$database = $_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$getuserinfo = sqlite_array_query($db, "SELECT user_nick,user_uploads,user_downloads FROM users WHERE id = '$_SESSION[user_id]' LIMIT 1", SQLITE_ASSOC);
//var_dump($getuserinfo);
$useratio = ($getuserinfo[0]['user_downloads'] != 0) ? $getuserinfo[0]['user_uploads'] / $getuserinfo[0]['user_downloads'] : 0;
sqlite_close($db);

$status = '
<div id="userinfo">
		<ul id="userinfo_username">
			<li id="us_username">Welcome back, <a href="index.php?p=profile&amp;uid='.$_SESSION['user_id'].'" title="my profile">'.$getuserinfo[0]['user_nick'].'</a></li>
			<li id="us_language">Locale: <a href="index.php?lang=US" title="English"><img src="'.$_CONFIG['site_url'].'/pages/images/us.png" border="0" alt="English" /> <img src="'.$_CONFIG['site_url'].'/pages/images/uk.png" border="0" alt="English" /></a> <a href="index.php?lang=GR" title="Greek"><img src="'.$_CONFIG['site_url'].'/pages/images/gr.png" border="0" alt="Greek" /></a></li>
		</ul>

		<ul id="userinfo_stats">
			<li id="st_up"><em>Up: </em><span class="stat">'.$getuserinfo[0]['user_uploads'].'</span></li>
			<li id="st_down"><em>Down: </em><span class="stat">'.$getuserinfo[0]['user_downloads'].'</span></li>
			<li id="st_ratio"><em>Ratio: </em><span class="stat"><span>'.$useratio.'</span></span></li>
		</ul>

		<ul id="userinfo_minor">
			<li id="mi_profile"><a href="index.php?p=profile&amp;uid='.$_SESSION['user_id'].'" title="My Profile!">'.$pLang->getPhrase(header5).'</a></li>
			<li class="nav_spacer">|</li>
			<li id="mi_logout"><a href="index.php?p=login&amp;action=logout" title="Logout">'.$pLang->getPhrase(header4).'</a></li>
		</ul>
</div>
';
} else {
$status = '
<div id="userinfo">
		<ul id="userinfo_username">
			<li id="us_username"></li>
			<li id="us_language">Locale: <a href="index.php?lang=US" title="English"><img src="'.$_CONFIG['site_url'].'/pages/images/us.png" border="0" alt="English" /> <img src="'.$_CONFIG['site_url'].'/pages/images/uk.png" border="0" alt="English" /></a> <a href="index.php?lang=GR" title="Greek"><img src="'.$_CONFIG['site_url'].'/pages/images/gr.png" border="0" alt="Greek" /></a></li>
		</ul>

		<ul id="userinfo_minor">
			<li id="mi_donate"><a href="http://nullfix.com/mycode/ezuploads/">Donate</a></li>
			<li class="nav_spacer">|</li>
			<li id="mi_tickets"><a href="index.php?p=login&amp;action=register" title="'.$pLang->getPhrase(header3).'">'.$pLang->getPhrase(header2).'</a></li>
			<li class="nav_spacer">|</li>
			<li id="mi_login"><a href="index.php?p=login" title="'.$pLang->getPhrase(header1).'" />'.$pLang->getPhrase(header0).'</li>
		</ul>
</div>
';
}
?>
<img id="userinfo_toggle" class="userinfo_toggle" src="<?php echo $_CONFIG['site_url'] ;?>/pages/images/userinfobutton_up.png" alt="Hide User Bar" title="Hide User Bar" onclick="ToggleUserInfo();"/>
<?php echo $status; ?>
<br />
<div align="center"><a href="<?php echo $_CONFIG['site_url'] ;?>"><img src="<?php echo $_CONFIG['site_url'] ;?>/pages/images/logo.png" border="0" alt="logo" /></a></div>
<h2><?php printf($pLang->getPhrase('introduction1'), $_CONFIG['site_name']); ?></h2>
</div>
