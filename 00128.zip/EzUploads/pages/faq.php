<!--Start of each accordion item-->
  <div id="test1-header" class="accordion_headings" ><?php p('heading2'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test1-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child">
	
		<h2><?php printf($pLang->getPhrase('faq1'), $_CONFIG['site_name']); ?></h2>
		<em>
		<?php printf($pLang->getPhrase('faq2'), $_CONFIG['site_name'], $_CONFIG['site_name']); ?>
		</em>										
		<h2><?php p('faq4'); ?></h2>
		<em>
		<?php printf($pLang->getPhrase('faq5'), $_CONFIG['site_name']); ?>
		</em>										
		<h2><?php p('faq7'); ?></h2>
		<em>
		<?php p('faq8'); ?>
		</em>										
		<h2><?php p('faq9'); ?></h2>
		<em>
		<?php p('faq10'); ?>
		</em>										
		<h2><?php p('faq11'); ?></h2>
		<em>
		<?php p('faq12'); ?>
		</em>										
		<h2><?php p('faq13'); ?></h2>
		<em>
		<?php p('faq14'); ?>
		</em>										

	</div>
    
  </div>
<!--End of each accordion item--> 