<!--Start of each accordion item-->
  <div id="test3-header" class="accordion_headings header_highlight">Public Gallery<?php //p('searchpage'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test3-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child" align="center">
<?php include('pages/adstop.inc'); ?>

<?php
// how many rows to show per page
$rowsPerPage = 24;
// by default we show first page
$pageNum = 1;
// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
    $pageNum = $_GET['page'];
}
// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;

$database = $_CONFIG['database_path'];
$dbhandle = sqlite_open($database, 0666, $sqliteerror);
$query = sqlite_query($dbhandle, "SELECT id,file_name FROM images WHERE type = 'public' ORDER BY id DESC LIMIT $offset, $rowsPerPage");
$query2 = sqlite_query($dbhandle, "SELECT id FROM images WHERE type = 'public'");
$numrows = sqlite_num_rows($query2);
$i = 0;

$results = '<table><tbody><tr><th></th><th></th><th></th><th></th></tr>';
while ($entry = sqlite_fetch_array($query, SQLITE_ASSOC))
  {
  $i++;
  $imagelink = $_CONFIG['site_url'].'/my.php?image='.$entry[file_name];
  $thumb = '<img src="'.$_CONFIG['site_url'].'/images/th_'.$entry[file_name].'" width="125" alt="thumb" />';

	if($i == 1):
  $results .= '<tr><td><a href="'.$imagelink.'" title="click for enlarge">'.$thumb.'</a><br />'.$entry[file_name].'</td>';
	elseif($i == 4):
  $results .= '<td><a href="'.$imagelink.'" title="click for enlarge">'.$thumb.'</a><br />'.$entry[file_name].'</td></tr>';
	else:
  $results .= '<td><a href="'.$imagelink.'" title="click for enlarge">'.$thumb.'</a><br />'.$entry[file_name].'</td>';
	endif;

	if($i == 4) { $i = 0; }
  }
$results .= '</tbody></table>';

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

// print the link to access each page
$self = $_SERVER['PHP_SELF'];

// creating previous and next link
// plus the link to go straight to
// the first and last page

if ($pageNum > 1)
{
   $page  = $pageNum - 1;
   $prev  = " <a href=\"$self?p=gallery&amp;page=$page\">[Prev]</a> ";

   $first = " <a href=\"$self?p=gallery&amp;page=1\">[First Page]</a> ";
}
else
{
   $prev  = '&nbsp;'; // we're on page one, don't print previous link
   $first = '&nbsp;'; // nor the first page link
}

if ($pageNum < $maxPage)
{
   $page = $pageNum + 1;
   $next = " <a href=\"$self?p=gallery&amp;page=$page\">[Next]</a> ";

   $last = " <a href=\"$self?p=gallery&amp;page=$maxPage\">[Last Page]</a> ";
}
else
{
   $next = '&nbsp;'; // we're on the last page, don't print next link
   $last = '&nbsp;'; // nor the last page link
}

// print the navigation link
$results .= "<p align=center>" . $first . $prev . " Showing page $pageNum of $maxPage pages " . $next . $last . "</p>";

sqlite_close($dbhandle);

// Type results to the page!
echo $results;
?>
    </div>
    
  </div>
<!--End of each accordion item-->