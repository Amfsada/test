<?php
// delete file routine
if ($_GET['p'] == 'action' && $_GET['del'] != '' && $_GET['dl'] != '')	{

// SQLite Read
$database = $_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$query = sqlite_array_query($db, "SELECT delete_id,file_name FROM files WHERE delete_id = '$_GET[del]'", SQLITE_ASSOC);

if ($query[0]['delete_id'] == '') {
$result = "<h3>".$pLang->getPhrase('error6')."</h3><br /><br />";
//$result .= '<br />'. print_r($query, false);
sqlite_close($db);
}

if ($_GET['del'] == $query[0]['delete_id'])	{
$result = "<h3>".$pLang->getPhrase('error4')."</h3><br /><br />";
$query2 = sqlite_query($db, "DELETE FROM files WHERE delete_id = '$_GET[del]'"); // delete the dbi file
sqlite_close($db);
$realfile = $_CONFIG['site_path'].'uploadz/'.$query[0]['file_name'];
@unlink($realfile); // delete the actual file
								}
}

// delete image routine
if ($_GET['p'] == 'action' && $_GET['del'] != '' && $_GET['img'] != '')	{

// SQLite Read
$database = $_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$query = sqlite_array_query($db, "SELECT delete_id,file_name FROM images WHERE delete_id = '$_GET[del]'", SQLITE_ASSOC);

if ($query[0]['delete_id'] == '') {
$result = "<h3>".$pLang->getPhrase('error6')."</h3><br /><br />";
//$result .= '<br />'. print_r($query, false);
sqlite_close($db);
}

if ($_GET['del'] == $query[0]['delete_id'])	{
$result = "<h3>".$pLang->getPhrase('error4')."</h3><br /><br />";
$query2 = sqlite_query($db, "DELETE FROM images WHERE delete_id = '$_GET[del]'"); // delete the dbi file
sqlite_close($db);
$realfile = $_CONFIG['site_path'].'/images/'.$query[0]['file_name'];
$thumb = $_CONFIG['site_path'].'/images/th_'.$query[0]['file_name'];
@unlink($realfile); // delete the actual file
@unlink($thumb);	}
}

// download file routine
if ($_GET['p'] == 'action' && !isset($_GET['del']) && $_GET['dl'] != '')	{

$filename = $_CONFIG['site_path']."uploadz/".$_GET['dl'];
$file = file_exists($filename);

if ($file == true) {
$showform = TRUE;
// SQLite get file info
$database = $_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$res = sqlite_array_query($db, "SELECT real_name,file_name,size,downloads FROM files WHERE file_name = '$_GET[dl]'", SQLITE_ASSOC);
sqlite_close($db);
}else{$result = "<h3>".$pLang->getPhrase('error5')."</h3><br /><br />";}
}

// generate download button if it passes captcha :)
if (isset($_SESSION['c_code']) && strtolower($_POST['code']) === strtolower($_SESSION['c_code'])) {

if ($_SESSION['user_logged'] === 1) {
// new wait counter for the file intended for registered users!
$result = '<h3>'.$pLang->getPhrase('fileform1').'</h3>' .
'<h1>'.$res[0][real_name].'</h1>'.
$pLang->getPhrase('fileform3').'<b>'.$res[0][size].'</b>'.
$pLang->getPhrase('fileform4').'<b>'.$res[0][downloads].'</b>'.$pLang->getPhrase('fileform5').
'<br /><br />'.
'<form method="post" action="dll.php" onsubmit="return disableForm(this);">'.
'<input type="hidden" name="id" value="'.$res[0][file_name].'">'.
'<input id="big" type="submit" value="'.$pLang->getPhrase('button1').'" style="font-size:20px;font-family:Arial;width:30%;height:40px;font-weight:bold;"></form>'.
'<script type="text/javascript" src="js/wait.js"></script>';
$showform = FALSE;
unset($_SESSION['c_code']);
} else {
// new wait counter for the file intended for unregistered users!
$result = '<h3>'.$pLang->getPhrase('fileform1').'</h3>' .
'<h1>'.$res[0][real_name].'</h1>'.
$pLang->getPhrase('fileform3').'<b>'.$res[0][size].'</b>'.
$pLang->getPhrase('fileform4').'<b>'.$res[0][downloads].'</b>'.$pLang->getPhrase('fileform5').
'<br /><br />'.
'<form style="display: none;" id="fileinfo" method="post" action="dll.php" onsubmit="return disableForm(this);">'.
'<input type="hidden" name="id" value="'.$res[0][file_name].'">'.
'<input id="big" type="submit" value="'.$pLang->getPhrase('button1').'" style="font-size:20px;font-family:Arial;width:30%;height:40px;font-weight:bold;"></form>'.
'<div id="count"><h1 id="wait" style="color:red;">&nbsp;</h1></div>'.
'<script type="text/javascript" src="js/wait.js"></script>';
$showform = FALSE;
unset($_SESSION['c_code']);
	}

}
?>

<!--Start of each accordion item-->
  <div id="test3-header" class="accordion_headings header_highlight"><?php p('button1'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test3-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child" align="center">
	<?php include('pages/adstop.inc'); ?>
<SCRIPT LANGUAGE="JavaScript">
<!-- Begin
function disableForm(theform) {
if (document.all || document.getElementById) {
for (i = 0; i < theform.length; i++) {
var tempobj = theform.elements[i];
if (tempobj.type.toLowerCase() == "submit" || tempobj.type.toLowerCase() == "reset")
tempobj.disabled = true;
}
//setTimeout('alert("Your form has been submitted.  Notice how the submit and reset buttons were disabled upon submission.")', 2000);
return true;
}
else {
//alert("The form has been submitted.  But, since you're not using IE 4+ or NS 6, the submit button was not disabled on form submission.");
return false;
   }
}
//  End -->
</SCRIPT>
<?php echo $result; ?>
<?php if ($showform == TRUE) { ?>
<h3><?php p('fileform2'); ?></h3>
<h1><?php echo $res[0][real_name]; ?></h1>
<?php p('fileform3'); ?><b><?php echo $res[0][size]; ?></b><?php p('fileform4'); ?><b><?php echo $res[0][downloads]; ?></b><?php p('fileform5'); ?>
<form method="post" action="" onsubmit="if(this.code.value==''){alert('Please enter the Code to be able to download the file');return false;}return true;">
<img src="getimage.php?<?php echo time(); ?>" alt="" name="captcha" width="155" height="45" id="captcha" /><br /><a href="javascript:void(0);" onclick="document.images['captcha'].src ='getimage.php'+ '?' + (new Date()).getTime();">Reload Captcha</a><br />
<input type="text" name="code" class="captcha_code">
<input type="submit" value="<?php p('button2'); ?>"></form>
<?php } ?>
    </div>
    
  </div>
<!--End of each accordion item-->
