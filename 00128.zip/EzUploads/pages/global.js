if (navigator.appName=="Netscape") {
	document.write("<style type='text/css'>body {overflow-y:scroll;}<\/style>");
}


function $() {
	var elements = new Array();
	for (var i = 0; i < arguments.length; i++) {
		var element = arguments[i];
		if (typeof element == 'string')
			element = document.getElementById(element);
		if (arguments.length == 1)
			return element;
		elements.push(element);
	}
	return elements;
}


function ToggleUserInfo() {

	if ($('userinfo').style.display == "none") {
		ShowUserInfo();
	} else {
		HideUserInfo();
	}

}

function HideUserInfo() {
	document.getElementById('userinfo').style.display = "none";
	document.getElementById('userinfo_toggle').setAttribute("src", 'http://' + window.location.hostname + '/pages/images/userinfobutton_down.png');
	document.getElementById('userinfo_toggle').setAttribute("alt", "Show User Bar");
	document.getElementById('userinfo_toggle').setAttribute("title", "Show User Bar");
	//document.body.style.paddingTop = "10px";
	
	
	if (document.getElementById('toolbar') != null ) {
			document.getElementById('toolbar').style.display = "none";
			//document.body.style.paddingBottom = "10px";
	}
}

function ShowUserInfo() {
	document.getElementById('userinfo').style.display = "block";
	document.getElementById('userinfo_toggle').setAttribute("src", 'http://' + window.location.hostname + '/pages/images/userinfobutton_up.png');
	document.getElementById('userinfo_toggle').setAttribute("alt", "Hide User Bar");
	document.getElementById('userinfo_toggle').setAttribute("title", "Hide User Bar");
	//document.body.style.paddingTop = "36px";
	
	
	if (document.getElementById('toolbar') != null ) {
			document.getElementById('toolbar').style.display = "block";
			//document.body.style.paddingBottom = "36px";
	}
}
