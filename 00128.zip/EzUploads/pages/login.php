<script type="text/javascript">
<!--
function delayer(){
    window.location = "<?php echo $_CONFIG['site_url']; ?>/index.php"
}
//-->
</script>

<?php
// global functions

// headers for php mails
$headers = 'From: '. $_CONFIG['from_email_address'] . "\r\n" .
    'Reply-To: '. $_CONFIG['from_email_address'] . "\r\n" .
    'X-Mailer: PHP/' . phpversion();

function imap8bit(&$item, $key) {
 $item = imap_8bit($item);
}

function email($e_mail, $subject, $message, $headers)
 {
  // add headers for utf-8 message
  $headers .= "\r\n";
  $headers .= "MIME-Version: 1.0\r\n";
  $headers .= "Content-type: text/plain; charset=utf-8\r\n";
  $headers .= "Content-Transfer-Encoding: quoted-printable\r\n";

  // encode subject
  //=?UTF-8?Q?encoded_text?=

  // work a round: for subject with wordwrap
  // not fixed, no possibility to have one in a single char
  $subject = wordwrap($subject, 25, "\n", FALSE);
  $subject = explode("\n", $subject);
  array_walk($subject, imap8bit);
  $subject = implode("\r\n ", $subject);
  $subject = "=?UTF-8?Q?".$subject."?=";

  // encode e-mail message
  $message = imap_8bit($message);

  return(mail("$e_mail", "$subject", "$message", "$headers"));
 }

// login and session managment
// login & form checking
if ($_SESSION['user_logged'] != 1 && !isset($_REQUEST['action'])) {
$sreply = $pLang->getPhrase('login_e1');

if (isset($_POST['nick']) && isset($_POST['pass']))	{

// SQLite load login info to check if its true ;)
$database = $_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$res = sqlite_array_query($db, "SELECT user_nick,user_pass,id FROM users WHERE user_nick = '$_POST[nick]' LIMIT 1", SQLITE_ASSOC);

$_SESSION['user_logged'] = ($_POST['pass'] === str_rot13($res[0]['user_pass']) && $_POST['nick'] === $res[0]['user_nick']) ? 1 : 0;
$sreply = ($_POST['pass'] === str_rot13($res[0]['user_pass']) && $_POST['nick'] === $res[0]['user_nick']) ? $pLang->getPhrase('login_r1') : $pLang->getPhrase('login_r2');

if ($_SESSION['user_logged'] === 1) {
$_SESSION['user_id'] = $res[0]['id'];
$updateip = sqlite_query($db, "UPDATE users SET user_ip = '$_SERVER[REMOTE_ADDR]', user_laston = '$_SERVER[REQUEST_TIME]' WHERE id = '$_SESSION[user_id]'");
// java redirect to index page
echo '
<script type="text/javascript">
<!--
setTimeout("delayer()", 5000)
//-->
</script>
';
}

sqlite_close($db);
		}

$results = '<h3>'.$sreply.'</h3><br /><table width="50%"><tr><td>'.
'<form method="post" action="" onsubmit="if(this.nick.value==\'nick\' || this.pass.value==\'\'){alert(\'Please complete all fields\');return false;}return true;">'.
'<label style="float: right">Username: <input type="text" name="nick" value="" /></label><br /><br />'.
'<label style="float: right">Password: <input type="password" name="pass" value="" /></label>'.
'<p class="submit"><input type="submit" value="'.$pLang->getPhrase('login').'" /></p>'.
'<p class="forgetmenot">(<a href="index.php?p=login&amp;action=lostpw" title="'.$pLang->getPhrase('lostpw').'">'.$pLang->getPhrase('lostpw2').'</a>)</p></form></td></tr></table>';
}

// registration action managment
if ($_REQUEST['action'] == 'register' && $_SESSION['user_logged'] != 1) {

$sreply = $pLang->getPhrase('login_r3');

if (isset($_POST['nick']) && isset($_POST['mail']))	{

function validEmail($temp_email) { 
######## Three functions to HELP ######## 
        function valid_dot_pos($email) { 
            $str_len = strlen($email); 
            for($i=0; $i<$str_len; $i++) { 
                $current_element = $email[$i]; 
                if($current_element == "." && ($email[$i+1] == ".")) { 
                    return false; 
                    break; 
                } 
                else { 

                } 
            } 
            return true; 
        } 
        function valid_local_part($local_part) { 
            if(preg_match("/[^a-zA-Z0-9-_@.!#$%&'*\/+=?^`{\|}~]/", $local_part)) { 
                return false; 
            } 
            else { 
                return true; 
            } 
        } 
        function valid_domain_part($domain_part) { 
            if(preg_match("/[^a-zA-Z0-9@#\[\].]/", $domain_part)) { 
                return false; 
            } 
            elseif(preg_match("/[@]/", $domain_part) && preg_match("/[#]/", $domain_part)) { 
                return false; 
            } 
            elseif(preg_match("/[\[]/", $domain_part) || preg_match("/[\]]/", $domain_part)) { 
                $dot_pos = strrpos($domain_part, "."); 
                if(($dot_pos < strrpos($domain_part, "]")) || (strrpos($domain_part, "]") < strrpos($domain_part, "["))) { 
                    return true; 
                } 
                elseif(preg_match("/[^0-9.]/", $domain_part)) { 
                    return false; 
                } 
                else { 
                    return false; 
                } 
            } 
            else { 
                return true; 
            } 
        } 
        // trim() the entered E-Mail 
        $str_trimmed = trim($temp_email); 
        // find the @ position 
        $at_pos = strrpos($str_trimmed, "@"); 
        // find the . position 
        $dot_pos = strrpos($str_trimmed, "."); 
        // this will cut the local part and return it in $local_part 
        $local_part = substr($str_trimmed, 0, $at_pos); 
        // this will cut the domain part and return it in $domain_part 
        $domain_part = substr($str_trimmed, $at_pos); 
        if(!isset($str_trimmed) || is_null($str_trimmed) || empty($str_trimmed) || $str_trimmed == "") { 
            return false; 
        } 
        elseif(!valid_local_part($local_part)) { 
            return false; 
        } 
        elseif(!valid_domain_part($domain_part)) { 
            return false; 
        } 
        elseif($at_pos > $dot_pos) { 
            return false; 
        } 
        elseif(!valid_local_part($local_part)) { 
            return false; 
        } 
        elseif(($str_trimmed[$at_pos + 1]) == ".") { 
            return false; 
        } 
        elseif(!preg_match("/[(@)]/", $str_trimmed) || !preg_match("/[(.)]/", $str_trimmed)) { 
            $this->email_status = "Invalid E-Mail Address"; 
            return false; 
        } 
        else { 
            return true; 
        } 
} 

// SQLite load login info to check if its true ;)
$database = $_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$res2 = sqlite_query($db, "SELECT id FROM users WHERE user_mail = '$_POST[mail]' LIMIT 1");

if (sqlite_num_rows($res2) == 0 && $_POST['nick'] != '' && $_POST['mail'] != '' && validEmail($_POST['mail']) != false) {

// generate random string for pass
function random_string($max_length = 20, $random_chars = "abcdefghijklmnopqrstuvwxyz0123456789")
{
			for ($i = 0; $i < $max_length; $i++) {
				$random_key = mt_rand(0, strlen($random_chars));
				$random_string .= substr($random_chars, $random_key, 1);
			}
			return strtolower(str_shuffle($random_string));
}

$newuserpass = random_string(10);
$newuserdbpass = str_rot13($newuserpass);
$res3 = sqlite_query($db, "INSERT INTO users (user_nick, user_pass, user_mail, user_joined) VALUES ('$_POST[nick]','$newuserdbpass','$_POST[mail]','$_SERVER[REQUEST_TIME]')");

$message = 'Welcome to '.$_CONFIG['site_name']."\n\n".
'Login:'.$_POST[nick]."\n".
'Random Password: '.$newuserpass."\n\n".
$_CONFIG['site_url'];

mail($_POST['mail'], $_CONFIG['site_name']." Registration Info!", $message, $headers);
$sreply = $pLang->getPhrase('login_r4');
	} else { $sreply = $pLang->getPhrase('login_r5'); }
if (sqlite_num_rows($res2) == 1) { $sreply = $pLang->getPhrase('login_r6'); }

sqlite_close($db);
// close database and send mail with login & password.
}

$results = '<h3>'.$sreply.'</h3><br /><table width="50%"><tr><td>'.
'<form method="post" action="" onsubmit="if(this.nick.value==\'nick\' || this.mail.value==\'e-mail\'){alert(\'Please complete all fields\');return false;}return true;">'.
'<input type="hidden" name="action" value="register" /><br />'.
'<label style="float: right">Username: <input type="text" name="nick" value="" /></label><br /><br />'.
'<label style="float: right">Email: <input type="text" name="mail" value="" /></label>'.
'<p class="submit"><input type="submit" value="'.$pLang->getPhrase('register').'" /></p></form></td></tr></table>'.
'<p>'.$pLang->getPhrase('login_r7').'</p>';
}

// Type a message if the user is allready logged in!
if ($_SESSION['user_logged'] == 1 && !$_POST['nick'] && !$_POST['pass']) {

$results = '<br /><br /><h3>'.$pLang->getPhrase('login_r8').'</h3><br /><br />';
}

// logoff
if ($_SESSION['user_logged'] == 1 && $_REQUEST['action'] == 'logout') {
unset($_SESSION['user_logged']);
unset($_SESSION['user_id']);
$results = '<br /><br /><h3>'.$pLang->getPhrase('login_r9').'</h3><br /><br />';
echo '
<script type="text/javascript">
<!--
setTimeout("delayer()", 5000)
//-->
</script>
';
}

// Lost Password
if ($_SESSION['user_logged'] != 1 && $_REQUEST['action'] == 'lostpw') {
$sreply = $pLang->getPhrase('login_r10');

if (isset($_POST['lost_mail']))	{

// SQLite load mail info to check if its true ;)
$database = $_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$mailcheck = sqlite_array_query($db, "SELECT user_nick,user_mail,user_pass FROM users WHERE user_mail = '$_POST[lost_mail]' LIMIT 1", SQLITE_ASSOC);
$checkrows = sqlite_query($db, "SELECT id FROM users WHERE user_mail = '$_POST[lost_mail]' LIMIT 1");

if (sqlite_num_rows($checkrows) == 0 && $_POST['lost_mail'] != '') {
$sreply = $pLang->getPhrase('login_r11');
} else {
// user mail found resend registration mail!
$unencoded = str_rot13($mailcheck[0]['user_pass']);
$message = 'Welcome to '.$_CONFIG['site_name']."\n\n".
'Login:'.$mailcheck[0]['user_nick']."\n".
'Random Password: '.$unencoded."\n\n".
$_CONFIG['site_url'];

mail($_POST['lost_mail'], $_CONFIG['site_name']." Registration Info!", $message, $headers);
$sreply = $pLang->getPhrase('login_r12');
	}

sqlite_close($db);
}

$results = '<h3>'.$sreply.'</h3><br /><table width="50%"><tr><td>'.
'<form method="post" action="" onsubmit="if(this.lost_mail.value==\'e-mail\' || this.lost_mail.value==\'\'){alert(\'Please complete email field\');return false;}return true;">'.
'<input type="hidden" name="action" value="lostpw" /><br />'.
'<label style="float: right">Email: <input type="text" name="lost_mail" value="" /></label>'.
'<p class="submit"><input type="submit" value="'.$pLang->getPhrase('button2').'" /></p></form></td></tr></table>';
}
?>
<!--Start of each accordion item-->
  <div id="test3-header" class="accordion_headings header_highlight"><?php p('login'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test3-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child" align="center">
	<?php //include('pages/adstop.inc'); ?>
	<?php echo $results; ?>
    </div>  
  </div>
<!--End of each accordion item-->
