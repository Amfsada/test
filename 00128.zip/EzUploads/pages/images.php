<!--Start of each accordion item-->
  <div id="test3-header" class="accordion_headings header_highlight"><?php p('heading5'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test3-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child" align="center">
	<?php include('pages/adstop.inc'); ?>
	<br />

<?php
// === Include main Uploader class
$_SESSION['upload_type'] = "images";
include 'SolmetraUploader.php';

// === Instantiate the class
$solmetraUploader = new SolmetraUploader(
  './',           // a base path to Flash Uploader's directory (relative to the page)
  'upload.php',       // path to a file that handles file uploads (relative to uploader.swf) [optional]
  'config2.php'  // path to a server-side config file (relative to the page) [optional]
);

// === Gather uploaded files
// Flash Uploader populates PHP's own $_FILE global variable 
// with the information about uploaded files 
$solmetraUploader->gatherUploadedFiles();
if (isset($_FILES) && sizeof($_FILES)) {
  //echo '<h2>Uploaded files</h2>';
  //echo '<pre class="info">';
  //print_r($_FILES);
  //print_r($_SESSION);
  //echo '</pre>';

if($_SESSION['upload_type'] == 'images' && isset($_POST['type'])){

function file_extension($filename)
{
    $path_info = pathinfo($filename);
    return $path_info['extension'];
}

$randomdelete = rand();
$basename = preg_replace( '/^.+[\\\\\\/]/', '', $_FILES[firstFile][tmp_name] );
$exten = file_extension($_FILES[firstFile][name]);
$_SESSION['filesize'] = formatBytes($_FILES[firstFile][size]);
$_SESSION['filename'] = $basename.".".$exten;
$_SESSION['delurl'] = $_CONFIG['site_url'].'/?p=action&img='.$_SESSION['filename'].'&del='.$randomdelete;

rename($_CONFIG['site_path']."uploadz/".$basename, $_CONFIG['site_path']."images/".$basename.".".$exten);

// SQLite database write
$database = $_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$query = sqlite_query($db, "INSERT INTO images (delete_id, file_name, size, download_time, upload_ip, type) VALUES ('".$randomdelete."','".$_SESSION['filename']."','".$_SESSION[filesize]."','".time()."','".$_SERVER['REMOTE_ADDR']."','".$_POST['type']."')");


// thumb creator
include_once('thumbnail.inc.php');
$thumb = new Thumbnail($_CONFIG['site_path']."images/".$_SESSION['filename']);
$thumb->resize(300,300);
$thumb->cropFromCenter(250);
$thumb->createReflection(40,40,80,true,'#a4a4a4');
$thumb->save($_CONFIG['site_path']."images/th_".$_SESSION['filename'],100);
//if you're using php 4 version
//$thumb->destruct();

// update user uploads count
if ($_SESSION['user_logged'] === 1) {
$res3 = sqlite_array_query($db, "SELECT id,user_uploads FROM users WHERE id = '$_SESSION[user_id]'", SQLITE_ASSOC);
$dcount2 = $res3[0][user_uploads] + 1;
$dlluserupdate = sqlite_query($db, "UPDATE users SET user_uploads = '$dcount2' WHERE id = '$_SESSION[user_id]'");
$uploadupdate = sqlite_query($db, "UPDATE images SET user_id = '$_SESSION[user_id]' WHERE delete_id = '$randomdelete'");
}

sqlite_close($db);
echo "<script type='text/javascript'>document.location.href='?p=finish'</script>";
}

}
?>

	<div><a href="index.php?p=gallery" title="See our public image gallery!">Public Gallery</a> - <a href="index.php">Upload Files</a></div>
    <!-- Start Upload Form -->

<form action="" method="post">
<input type="radio" name="type" value="public" checked /> Public <input type="radio" name="type" value="private" /> Private<br />
<?php
echo $solmetraUploader->getInstance('firstFile',     // name of the field 
                                    500,              // width
                                    40,              // height
                                    false,            // not required - allow form to be submitted  
                                    true,             // hijack form (recommended)
                                    'custom.xml',     // let's use different front-end config file than specified in the config.php 
                                                      // (please note that this URL is relative to this demo file) 
                                    true              // embed config (this will load front-end configuration XML file and embed it in the HTML) 
                                    );
?>
<br />
<input type="submit" value="Upload Image" style="font-size:20px;font-family:Arial;width:40%;height:40px;font-weight:bold;" />
</form>

	<p><a href="<?php echo $_CONFIG['site_url']; ?>/?p=login&amp;action=register" title="Register for FREE and earn from your uploads + get more features!">Register for FREE</a> and earn from your uploads + get more features:<br />keep track of your uploads/downloads - instant download without counter! - check other users public profile<br />use our remote upload tool - create edit your profile - manage your files and much more!</p>
    <!-- End Upload Form -->

    </div>
  </div>
<!--End of each accordion item-->