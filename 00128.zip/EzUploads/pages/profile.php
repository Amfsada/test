<!--Start of each accordion item-->
  <div id="test3-header" class="accordion_headings header_highlight"><?php p('profile'); ?></div><!--Heading of the accordion ( clicked to show n hide ) -->
  
  <!--Prefix of heading (the DIV above this) and content (the DIV below this) to be same... eg. foo-header & foo-content-->
  
  <div id="test3-content"><!--DIV which show/hide on click of header-->
  
  	<!--This DIV is for inline styling like padding...-->
    <div class="accordion_child">
<?php //include('pages/adstop.inc'); ?>
<?php
	// time function :)
    if(!function_exists('how_long_ago')){
        function how_long_ago($timestamp){
            $difference = time() - $timestamp;

            if($difference >= 60*60*24*365){        // if more than a year ago
                $int = intval($difference / (60*60*24*365));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' year' . $s . ' ago';
            } elseif($difference >= 60*60*24*7*5){  // if more than five weeks ago
                $int = intval($difference / (60*60*24*30));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' month' . $s . ' ago';
            } elseif($difference >= 60*60*24*7){        // if more than a week ago
                $int = intval($difference / (60*60*24*7));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' week' . $s . ' ago';
            } elseif($difference >= 60*60*24){      // if more than a day ago
                $int = intval($difference / (60*60*24));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' day' . $s . ' ago';
            } elseif($difference >= 60*60){         // if more than an hour ago
                $int = intval($difference / (60*60));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' hour' . $s . ' ago';
            } elseif($difference >= 60){            // if more than a minute ago
                $int = intval($difference / (60));
                $s = ($int > 1) ? 's' : '';
                $r = $int . ' minute' . $s . ' ago';
            } else {                                // if less than a minute ago
                $r = 'moments ago';
            }

            return $r;
        }
    }

// start my profile
// major changes :)
if ($_SESSION['user_logged'] === 1 && $_REQUEST['uid'] == $_SESSION['user_id']) { // only for logged in users
// SQLite load user info to to display
$database = $_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$userinfo = sqlite_array_query($db, "SELECT user_nick,user_pass,user_mail,user_web,user_uploads,user_downloads,user_joined FROM users WHERE id = '$_SESSION[user_id]' LIMIT 1", SQLITE_ASSOC);

// how many rows to show per page
$rowsPerPage = 10;
// by default we show first page
$pageNum = 1;
// if $_GET['page'] defined, use it as page number
if(isset($_GET['page']))
{
    $pageNum = $_GET['page'];
}
// counting the offset
$offset = ($pageNum - 1) * $rowsPerPage;
$fileinfo = sqlite_query($db, "SELECT real_name,delete_id,file_name,size,downloads FROM files WHERE user_id = '$_SESSION[user_id]' LIMIT $offset, $rowsPerPage");
$i = 0;
$query2 = sqlite_query($db, "SELECT id FROM files WHERE user_id = '$_SESSION[user_id]'");
$numrows = sqlite_num_rows($query2);

// Gravatar setup
$default = $_CONFIG['site_url']."/pages/images/gravatar.gif";
$size = 80;

$grav_url = "http://www.gravatar.com/avatar.php?
gravatar_id=".md5($userinfo[0]['user_mail']).
"&default=".urlencode($default).
"&size=".$size; 

$results = '<h2>'.$pLang->getPhrase('profile2').'</h2>'.
'<form method="post" action="" onsubmit="if(this.nick.value==\'\' || this.pass.value==\'\'){alert(\'Please complete all fields\');return false;}return true;">'.
'<p align="right">'.$pLang->getPhrase('profile3').': <input disabled type="text" name="" value="'.$userinfo[0]['user_nick'].'" size="16" /></p>'.
'<p align="right">'.$pLang->getPhrase('profile4').': <input type="text" name="pass" value="'.str_rot13($userinfo[0]['user_pass']).'" size="10" /></p>'.
'<p align="right">'.$pLang->getPhrase('profile5').': <input disabled type="text" name="" value="'.$userinfo[0]['user_mail'].'" size="30" /></p>'.
'<p align="right">'.$pLang->getPhrase('profile6').': <input type="text" name="website" value="'.$userinfo[0]['user_web'].'" size="50" /></p>'.
'<p align="right">'.$pLang->getPhrase('profile7').' : <img src="'.$_CONFIG['site_url'].'/pages/images/clock.png" alt="clock" /> '.how_long_ago($userinfo[0]['user_joined']).'</p>'.
'<input type="hidden" name="action" value="submit" />'.
'<p align="right"><input align="right" type="submit" value="'.$pLang->getPhrase('profile1').'" /></p></form>'.
'<h2>'.$pLang->getPhrase('profile8').' (<a href="http://www.gravatar.com/"  title="What is Gravatar?" target="_blank">Gravatar</a>)</h2>'.
'<p align="right"><img src="'.$grav_url.'" alt="Gravatar" /></p>'.
'<h2>'.$pLang->getPhrase('profile9').'</h2>'.
'<p align="right" id="big">'.$pLang->getPhrase('profile10').': <img src="'.$_CONFIG['site_url'].'/pages/images/arrow_up.png" alt="uploads" />'.$userinfo[0]['user_uploads'].'</p>'.
'<p align="right" id="big">'.$pLang->getPhrase('profile11').': <img src="'.$_CONFIG['site_url'].'/pages/images/arrow_down.png" alt="downloads" />'.$userinfo[0]['user_downloads'].'</p>'.
'<p></p>'.
'<h2>'.$pLang->getPhrase('profile12').'</h2>';

$results .= '<table><tbody><tr><th>No</th><th>'.$pLang->getPhrase(filename).'</th><th>DLL</th><th>'.$pLang->getPhrase(size).'</th><th>'.$pLang->getPhrase(actions).'</th></tr>';
while ($entry = sqlite_fetch_array($fileinfo, SQLITE_ASSOC))
  {
  $i++;
  $nametrim = (strlen($entry[real_name]) > 55) ? substr($entry[real_name], 0, 55) : $entry[real_name];
  $dlink = '<a title="'.$pLang->getPhrase(button1).'" href="'.$_CONFIG['site_url'].'/index.php?p=action&amp;dl='.$entry[file_name].'" target="_blank"><img src="'.$_CONFIG['site_url'].'/pages/images/dll.png" alt="download" /></a>';
  $deletefile = ' <a href="'.$_CONFIG['site_url'].'/index.php?p=action&amp;dl='.$entry[file_name].'&amp;del='.$entry[delete_id].'" title="Delete this file" onclick="return confirm(\'Are you sure you want to delete this file?\')"><img src="'.$_CONFIG['site_url'].'/pages/images/exclamation.png" alt="delete" /></a>';
  $results .= '<tr><td>'.$i.'</td><td>'.$nametrim.'</a></td><td>'.$entry[downloads].'</td>'.'<td>'.$entry[size].'</td><td>'.$dlink.$deletefile.'</td></tr>';
  }
$results .= '</tbody></table>';

if ($_POST['action'] == 'submit' && $_POST['pass'] != '') {
$newpass = str_rot13($_POST['pass']);
$updatedbuser = sqlite_query($db, "UPDATE users SET user_pass = '$newpass', user_web ='$_POST[website]' WHERE id = '$_SESSION[user_id]'");
$results = '<center>'.$pLang->getPhrase('profile14').'</center>';
}

// how many pages we have when using paging?
$maxPage = ceil($numrows/$rowsPerPage);

// print the link to access each page
$self = $_SERVER['PHP_SELF'];

// creating previous and next link
// plus the link to go straight to
// the first and last page

if ($pageNum > 1)
{
   $page  = $pageNum - 1;
   $prev  = " <a href=\"$self?p=profile&amp;uid=$_SESSION[user_id]&amp;page=$page\">[Prev]</a> ";

   $first = " <a href=\"$self?p=profile&amp;uid=$_SESSION[user_id]&amp;page=1\">[First Page]</a> ";
}
else
{
   $prev  = '&nbsp;'; // we're on page one, don't print previous link
   $first = '&nbsp;'; // nor the first page link
}

if ($pageNum < $maxPage)
{
   $page = $pageNum + 1;
   $next = " <a href=\"$self?p=profile&amp;uid=$_SESSION[user_id]&amp;page=$page\">[Next]</a> ";

   $last = " <a href=\"$self?p=profile&amp;uid=$_SESSION[user_id]&amp;page=$maxPage\">[Last Page]</a> ";
}
else
{
   $next = '&nbsp;'; // we're on the last page, don't print next link
   $last = '&nbsp;'; // nor the last page link
}

// print the navigation link
$results .= "<p align=center>" . $first . $prev . " Showing page $pageNum of $maxPage pages " . $next . $last . "</p>";

sqlite_close($db);
} else { $results = '<center>'.$pLang->getPhrase('error7').'</center>'; }

// start of public profile
// major changes :)
if ($_SESSION['user_logged'] === 1 && $_REQUEST['uid'] != $_SESSION['user_id']) { // only for logged in users public profile

// SQLite load user info to to display
$database = $_CONFIG['database_path'];
$db = sqlite_open($database, 0666, $sqliteerror);
$userinfo = sqlite_array_query($db, "SELECT user_nick,user_mail,user_web,user_uploads,user_downloads FROM users WHERE id = '$_REQUEST[uid]' LIMIT 1", SQLITE_ASSOC);
$fileinfo = sqlite_query($db, "SELECT real_name,file_name,size,downloads FROM files WHERE user_id = '$_REQUEST[uid]' ORDER by downloads DESC LIMIT 10");
$i = 0;

// Gravatar setup
$default = $_CONFIG['site_url']."/pages/images/gravatar.gif";
$size = 80;

$grav_url = "http://www.gravatar.com/avatar.php?
gravatar_id=".md5($userinfo[0]['user_mail']).
"&default=".urlencode($default).
"&size=".$size; 

// site url parse
$siteurl = parse_url($userinfo[0]['user_web']);

$results = '<h2>'.$userinfo[0]['user_nick'].'\'s Profile</h2>'.
'<p><img src="'.$grav_url.'" alt="Gravatar" /></p>'.
'<p id="big">'.$pLang->getPhrase('profile3').': '.$userinfo[0]['user_nick'].'</p>'.
'<p id="big">'.$pLang->getPhrase('profile6').': <a href="http://'.$siteurl['host'].'" target="_blank">'.$siteurl['host'].'</a></p>'.
'<h2>'.$pLang->getPhrase('profile9').'</h2>'.
'<p id="big">'.$pLang->getPhrase('profile15').': <img src="/pages/images/arrow_up.png" alt="uploads" />'.$userinfo[0]['user_uploads'].'</p>'.
'<p id="big">'.$pLang->getPhrase('profile16').': <img src="/pages/images/arrow_down.png" alt="downloads" />'.$userinfo[0]['user_downloads'].'</p>'.
'<h2>'.$pLang->getPhrase('profile13').' <font color=red>'.$userinfo[0]['user_nick'].'</font></h2>';

$results .= '<table><tbody><tr><th>No</th><th>'.$pLang->getPhrase(filename).'</th><th>DLL</th><th>'.$pLang->getPhrase(size).'</th><th>'.$pLang->getPhrase(actions).'</th></tr>';
while ($entry = sqlite_fetch_array($fileinfo, SQLITE_ASSOC))
  {
  $i++;
  $nametrim = (strlen($entry[real_name]) > 55) ? substr($entry[real_name], 0, 55) : $entry[real_name];
  $dlink = '<a title="'.$pLang->getPhrase(button1).'" href="'.$_CONFIG['site_url'].'/dll/'.$entry[file_name].'" target="_blank"><img src="'.$_CONFIG['site_url'].'/pages/images/dll.png" alt="download" /></a>';
  $results .= '<tr><td>'.$i.'</td><td>'.$nametrim.'</a></td><td>'.$entry[downloads].'</td>'.'<td>'.$entry[size].'</td><td>'.$dlink.'</td></tr>';
  }
$results .= '</tbody></table>';

sqlite_close($db);

// if user does not exist?
if ($userinfo[0]['user_mail'] == '' || $userinfo[0]['user_nick'] == '') { $results = "<center>I can't find that user in our database!</center>"; }

}
// Type results to the page!
echo $results;
?>
    </div>   
  </div>
<!--End of each accordion item-->